package com.flancher.tv

import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * مشغّل القرآن: كائن واحد يعيش مع التطبيق، فيستمر الصوت أثناء التنقل بين الشاشات.
 */
object QuranPlayer {
    var reciter by mutableStateOf<Reciter?>(null)
        private set
    var surah by mutableStateOf(0)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var isPreparing by mutableStateOf(false)
        private set
    var error by mutableStateOf(false)
        private set

    private var mp: MediaPlayer? = null
    private var onChange: (() -> Unit)? = null

    /** يُستدعى عند تغيّر القارئ/السورة لحفظها */
    fun setOnChange(cb: () -> Unit) {
        onChange = cb
    }

    val positionMs: Int
        get() = try {
            if (mp != null && !isPreparing) mp!!.currentPosition else 0
        } catch (e: Exception) {
            0
        }

    val durationMs: Int
        get() = try {
            if (mp != null && !isPreparing) mp!!.duration.coerceAtLeast(0) else 0
        } catch (e: Exception) {
            0
        }

    fun play(r: Reciter, s: Int) {
        release()
        reciter = r
        surah = s
        error = false
        isPreparing = true
        isPlaying = false
        onChange?.invoke()
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(surahUrl(r, s))
            p.setOnPreparedListener {
                isPreparing = false
                it.start()
                isPlaying = true
            }
            p.setOnCompletionListener { next() }
            p.setOnErrorListener { _, _, _ ->
                isPreparing = false
                isPlaying = false
                error = true
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            isPreparing = false
            error = true
        }
    }

    fun toggle() {
        val p = mp ?: return
        try {
            if (p.isPlaying) {
                p.pause(); isPlaying = false
            } else if (!isPreparing) {
                p.start(); isPlaying = true
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun next() {
        val r = reciter ?: return
        val i = r.surahs.indexOf(surah)
        val n = r.surahs.getOrNull(i + 1) ?: r.surahs.first()
        play(r, n)
    }

    fun previous() {
        val r = reciter ?: return
        val i = r.surahs.indexOf(surah)
        val n = r.surahs.getOrNull(i - 1) ?: r.surahs.last()
        play(r, n)
    }

    fun seekTo(ms: Int) {
        try {
            mp?.seekTo(ms)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun stop() {
        release()
        isPlaying = false
        isPreparing = false
    }

    private fun release() {
        try {
            mp?.release()
        } catch (e: Exception) {
            // ignore
        }
        mp = null
    }
}
