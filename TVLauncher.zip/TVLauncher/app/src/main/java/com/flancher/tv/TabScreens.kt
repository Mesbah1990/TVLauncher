package com.flancher.tv

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color

@Composable
fun AppsBody(st: LauncherState) {
    AppGrid(st.apps, stringResource(R.string.empty_list), onLong = { st.actionApp = it.pkg }) {
        st.launch(it.pkg)
    }
}

@Composable
fun ContentBody(st: LauncherState) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 30.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        MoviesCard(Modifier.weight(1f).height(170.dp), st) {
            if (st.app(st.moviesApp) != null) st.launch(st.moviesApp) else st.picker = PickerTarget.Movies
        }
        LiveCard(Modifier.weight(1f).height(170.dp), st) {
            if (st.app(st.liveApp) != null) st.launch(st.liveApp) else st.picker = PickerTarget.Live
        }
    }
}

@Composable
fun FavoritesBody(st: LauncherState) {
    val list = st.favorites.mapNotNull { st.app(it) }
    AppGrid(list, stringResource(R.string.empty_list), onLong = { st.actionApp = it.pkg }) { st.launch(it.pkg) }
}

@Composable
fun HistoryBody(st: LauncherState) {
    val list = st.history.mapNotNull { st.app(it) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
            TvCard(
                Modifier.height(34.dp).width(150.dp),
                shape = RoundedCornerShape(17.dp),
                onClick = { st.clearHistory() },
            ) { Txt(stringResource(R.string.clear_history), 13.sp, modifier = Modifier.align(Alignment.Center)) }
        }
        Column(Modifier.weight(1f)) {
            AppGrid(list, stringResource(R.string.empty_list), onLong = { st.actionApp = it.pkg }) { st.launch(it.pkg) }
        }
    }
}

/** كل النوافذ المنبثقة: اختيار التطبيقات، قائمة التطبيق، المدينة، المواقيت */
@Composable
fun Dialogs(st: LauncherState) {
    val ctx = LocalContext.current

    st.picker?.let { target ->
        val title = when (target) {
            PickerTarget.Live -> stringResource(R.string.choose_app_live)
            PickerTarget.Movies -> stringResource(R.string.choose_app_movies)
            PickerTarget.Pin -> stringResource(R.string.choose_app)
        }
        val current = when (target) {
            PickerTarget.Live -> st.liveApp
            PickerTarget.Movies -> st.moviesApp
            PickerTarget.Pin -> ""
        }
        AppPickerDialog(
            title = title,
            apps = st.apps,
            onPick = { st.assign(target, it.pkg) },
            onClear = if (current.isNotEmpty()) ({ st.assign(target, "") }) else null,
            onDismiss = { st.picker = null },
        )
    }

    st.actionApp?.let { pkg ->
        val fav = pkg in st.favorites
        val pin = pkg in st.pinned
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += (if (fav) stringResource(R.string.remove_favorite) else stringResource(R.string.add_favorite)) to
            { st.toggleFavorite(pkg) }
        items += (if (pin) stringResource(R.string.remove) + " (" + stringResource(R.string.nav_home) + ")"
        else stringResource(R.string.nav_home) + " +") to { st.togglePinned(pkg) }
        items += stringResource(R.string.app_info) to {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        items += stringResource(R.string.uninstall) to {
            runCatching {
                ctx.startActivity(
                    Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        MenuDialog(st.app(pkg)?.label ?: pkg, items) { st.actionApp = null }
    }

    if (st.showCityDialog) {
        ListDialog(
            title = stringResource(R.string.city),
            entries = CITIES.map { it.name(st.lang) to (it.key == st.cityKey) },
            onPick = { st.setCity(CITIES[it].key) },
            onDismiss = { st.showCityDialog = false },
        )
    }

    if (st.showPrayerDialog) PrayerDialog(st) { st.showPrayerDialog = false }
}

@Composable
fun PrayerDialog(st: LauncherState, onDismiss: () -> Unit) {
    val p = st.prayers
    val names = listOf(
        stringResource(R.string.fajr), stringResource(R.string.sunrise), stringResource(R.string.dhuhr),
        stringResource(R.string.asr), stringResource(R.string.maghrib), stringResource(R.string.isha),
    )
    val fr = androidx.compose.runtime.remember { androidx.compose.ui.focus.FocusRequester() }
    androidx.compose.runtime.LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            Modifier.fillMaxWidth(0.4f)
                .androidxClip()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Txt(stringResource(R.string.prayer_times) + " — " + st.city.name(st.lang), 18.sp,
                weight = androidx.compose.ui.text.font.FontWeight.Bold)
            if (p == null) {
                Txt(stringResource(R.string.error_network), 15.sp)
            } else {
                p.asList().forEachIndexed { i, t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Txt(names[i], 17.sp, modifier = Modifier.weight(1f))
                        Txt(t, 17.sp, color = Gold, weight = androidx.compose.ui.text.font.FontWeight.Bold)
                    }
                }
            }
            TvCard(
                Modifier.fillMaxWidth().height(38.dp),
                focusRequester = fr,
                onClick = onDismiss,
            ) { Txt(stringResource(R.string.close), 15.sp, modifier = Modifier.align(Alignment.Center)) }
        }
    }
}

private fun Modifier.androidxClip(): Modifier =
    this.then(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xF2101739)))
