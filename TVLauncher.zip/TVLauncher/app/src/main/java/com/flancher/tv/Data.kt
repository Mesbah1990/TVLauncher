package com.flancher.tv

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** مدينة للطقس ومواقيت الصلاة / ville pour météo et prières / city for weather & prayer */
data class City(
    val key: String,
    val ar: String,
    val fr: String,
    val en: String,
    val lat: Double,
    val lon: Double,
    val method: Int, // Aladhan calculation method
) {
    fun name(lang: String) = when (lang) {
        "ar" -> ar
        "fr" -> fr
        else -> en
    }
}

val CITIES = listOf(
    City("algiers", "الجزائر", "Alger", "Algiers", 36.75, 3.06, 19),
    City("oran", "وهران", "Oran", "Oran", 35.69, -0.64, 19),
    City("constantine", "قسنطينة", "Constantine", "Constantine", 36.37, 6.61, 19),
    City("annaba", "عنابة", "Annaba", "Annaba", 36.90, 7.77, 19),
    City("setif", "سطيف", "Sétif", "Setif", 36.19, 5.41, 19),
    City("batna", "باتنة", "Batna", "Batna", 35.56, 6.17, 19),
    City("tlemcen", "تلمسان", "Tlemcen", "Tlemcen", 34.88, -1.32, 19),
    City("biskra", "بسكرة", "Biskra", "Biskra", 34.85, 5.73, 19),
    City("eloued", "الوادي", "El Oued", "El Oued", 33.37, 6.86, 19),
    City("ouargla", "ورقلة", "Ouargla", "Ouargla", 31.95, 5.32, 19),
    City("ghardaia", "غرداية", "Ghardaïa", "Ghardaia", 32.49, 3.67, 19),
    City("tamanrasset", "تمنراست", "Tamanrasset", "Tamanrasset", 22.79, 5.53, 19),
    City("tunis", "تونس", "Tunis", "Tunis", 36.81, 10.18, 18),
    City("casablanca", "الدار البيضاء", "Casablanca", "Casablanca", 33.57, -7.59, 21),
    City("cairo", "القاهرة", "Le Caire", "Cairo", 30.04, 31.24, 5),
    City("makkah", "مكة المكرمة", "La Mecque", "Makkah", 21.42, 39.83, 4),
    City("riyadh", "الرياض", "Riyad", "Riyadh", 24.71, 46.68, 4),
    City("dubai", "دبي", "Dubaï", "Dubai", 25.20, 55.27, 16),
    City("istanbul", "إسطنبول", "Istanbul", "Istanbul", 41.01, 28.98, 13),
    City("paris", "باريس", "Paris", "Paris", 48.86, 2.35, 12),
    City("london", "لندن", "Londres", "London", 51.51, -0.13, 3),
)

fun cityByKey(key: String): City = CITIES.firstOrNull { it.key == key } ?: CITIES[8]

/** خلفيات جاهزة / arrière-plans prédéfinis / built-in wallpapers */
val WALLPAPER_PRESETS: List<Pair<String, Brush>> = listOf(
    "sunset" to Brush.verticalGradient(
        listOf(Color(0xFF2B1B5E), Color(0xFF8A3FA8), Color(0xFFE8764A), Color(0xFF1C2A4A), Color(0xFF0B1B2E))
    ),
    "night" to Brush.verticalGradient(
        listOf(Color(0xFF050A1F), Color(0xFF0B1B45), Color(0xFF14295E), Color(0xFF050A1F))
    ),
    "emerald" to Brush.verticalGradient(
        listOf(Color(0xFF03150F), Color(0xFF0B4D3A), Color(0xFF127A5A), Color(0xFF04201A))
    ),
    "ocean" to Brush.verticalGradient(
        listOf(Color(0xFF021B3A), Color(0xFF0A5C9C), Color(0xFF27A3C9), Color(0xFF021B3A))
    ),
    "royal" to Brush.verticalGradient(
        listOf(Color(0xFF1A0B3B), Color(0xFF4B1D8F), Color(0xFFB0457E), Color(0xFF1A0B3B))
    ),
    "graphite" to Brush.verticalGradient(
        listOf(Color(0xFF0E0F12), Color(0xFF23262D), Color(0xFF3A3F49), Color(0xFF0E0F12))
    ),
)

fun presetBrush(key: String): Brush =
    WALLPAPER_PRESETS.firstOrNull { it.first == key }?.second ?: WALLPAPER_PRESETS[0].second

val SURAH_NAMES_AR = listOf(
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
    "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
    "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
    "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
    "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
    "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
    "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
    "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
    "المسد", "الإخلاص", "الفلق", "الناس",
)

/** حزمة القرّاء الأساسية: عند فشل جلب القائمة الكاملة من الإنترنت */
data class Reciter(
    val id: Int,
    val name: String,
    val server: String,
    val surahs: List<Int>,
)

private val ALL_114 = (1..114).toList()

val FALLBACK_RECITERS = listOf(
    Reciter(1, "مشاري راشد العفاسي", "https://server8.mp3quran.net/afs/", ALL_114),
    Reciter(2, "عبد الباسط عبد الصمد", "https://server7.mp3quran.net/basit/", ALL_114),
    Reciter(3, "عبد الرحمن السديس", "https://server11.mp3quran.net/sds/", ALL_114),
    Reciter(4, "سعود الشريم", "https://server7.mp3quran.net/shur/", ALL_114),
    Reciter(5, "ماهر المعيقلي", "https://server12.mp3quran.net/maher/", ALL_114),
    Reciter(6, "سعد الغامدي", "https://server7.mp3quran.net/s_gmd/", ALL_114),
    Reciter(7, "ياسر الدوسري", "https://server11.mp3quran.net/yasser/", ALL_114),
    Reciter(8, "محمود خليل الحصري", "https://server13.mp3quran.net/husr/", ALL_114),
    Reciter(9, "محمد صديق المنشاوي", "https://server10.mp3quran.net/minsh/", ALL_114),
)

/** كلمات للتعرف على القرّاء المشهورين وعرضهم أولاً (عربي / لاتيني) */
val FEATURED_KEYWORDS = listOf(
    listOf("مشاري", "العفاسي", "mishary", "alafasy", "afasy"),
    listOf("عبد الباسط", "abdulbasit", "abdul basit", "abdelbasset"),
    listOf("السديس", "sudais", "sudays"),
    listOf("الشريم", "shuraim", "shuraym"),
    listOf("ماهر المعيقلي", "maher", "muaiqly", "mueaqly"),
    listOf("سعد الغامدي", "ghamdi", "ghamadi"),
    listOf("ياسر الدوسري", "dossari", "dosari", "dawsari"),
    listOf("الحصري", "husary", "hussary", "hosary"),
    listOf("المنشاوي", "minshawi", "minshawy"),
    listOf("القطامي", "qatami", "katami"),
    listOf("العجمي", "ajamy", "ajmi"),
    listOf("البلوشي", "baloushi", "balushi"),
    listOf("أبكر", "abkar", "idrees"),
    listOf("الحذيفي", "hudhaify", "hudhaifi", "hudaify"),
    listOf("بندر بليلة", "baleela", "balila"),
)
