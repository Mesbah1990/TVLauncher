package com.flancher.tv

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex

val Gold = Color(0xFFFFC83D)
val PanelBrush = Brush.verticalGradient(listOf(Color(0xCC1D2770), Color(0xCC0B1238)))
val FlatPanel = Brush.verticalGradient(listOf(Color(0xE6101739), Color(0xE6101739)))
fun solid(c: Color) = Brush.verticalGradient(listOf(c, c))

@Composable
fun Txt(
    text: String,
    size: TextUnit = 14.sp,
    color: Color = Color.White,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
    maxLines: Int = 1,
) {
    Text(
        text = text,
        fontSize = size,
        color = color,
        fontWeight = weight,
        modifier = modifier,
        textAlign = align,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

/** بطاقة قابلة للتركيز بالريموت: تكبر وتُضاء بإطار ذهبي */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TvCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    background: Brush = PanelBrush,
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "scale")
    Box(
        modifier = modifier
            .zIndex(if (focused) 1f else 0f)
            .scale(scale)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(background)
            .border(
                if (focused) 3.dp else 1.dp,
                if (focused) Gold else Color.White.copy(alpha = 0.18f),
                shape,
            )
            .onPreviewKeyEvent { e ->
                if (onLongClick != null && e.type == KeyEventType.KeyUp && e.key == Key.Menu) {
                    onLongClick(); true
                } else false
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        content = content,
    )
}

@Composable
fun VDivider() {
    Box(
        Modifier
            .padding(horizontal = 10.dp)
            .width(1.dp)
            .height(22.dp)
            .background(Color.White.copy(alpha = 0.3f))
    )
}

@Composable
fun IconBtn(icon: ImageVector, desc: String, onClick: () -> Unit) {
    TvCard(
        modifier = Modifier.size(34.dp),
        shape = CircleShape,
        background = solid(Color.Transparent),
        onClick = onClick,
    ) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(22.dp))
    }
}

/** بطاقة عريضة: أيقونة + عنوان + عنوان فرعي */
@Composable
fun WideCard(
    modifier: Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    brush: Brush,
    iconTint: Color = Gold,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    TvCard(modifier = modifier, background = brush, onLongClick = onLongClick, onClick = onClick) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Txt(title, 19.sp, weight = FontWeight.Bold)
                Txt(subtitle, 13.sp, color = Color.White.copy(alpha = 0.75f))
            }
            Icon(icon, null, tint = iconTint, modifier = Modifier.size(46.dp))
        }
    }
}

/** بلاطة تطبيق: أيقونة + اسم */
@Composable
fun AppTile(
    app: AppInfo,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    TvCard(
        modifier = modifier,
        focusRequester = focusRequester,
        background = FlatPanel,
        onLongClick = onLongClick,
        onClick = onClick,
    ) {
        Column(
            Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            if (app.icon != null) {
                Image(app.icon, null, Modifier.size(52.dp), contentScale = ContentScale.Fit)
            }
            Txt(app.label, 12.sp, align = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/** شبكة تطبيقات عامة */
@Composable
fun AppGrid(
    list: List<AppInfo>,
    emptyText: String = "",
    onLong: ((AppInfo) -> Unit)? = null,
    onPick: (AppInfo) -> Unit,
) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(list.size) {
        if (list.isNotEmpty()) runCatching { fr.requestFocus() }
    }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Txt(emptyText, 18.sp, color = Color.White.copy(alpha = 0.7f))
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(112.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(list, key = { it.pkg }) { app ->
            AppTile(
                app = app,
                modifier = Modifier.fillMaxWidth().height(100.dp),
                focusRequester = if (app == list.first()) fr else null,
                onLongClick = onLong?.let { f -> { f(app) } },
                onClick = { onPick(app) },
            )
        }
    }
}

/** نافذة اختيار تطبيق */
@Composable
fun AppPickerDialog(
    title: String,
    apps: List<AppInfo>,
    onPick: (AppInfo) -> Unit,
    onClear: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.82f)
                .fillMaxHeight(0.86f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xF2101739))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(title, 20.sp, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (onClear != null) {
                    TvCard(
                        Modifier.height(36.dp).width(110.dp),
                        shape = RoundedCornerShape(18.dp),
                        onClick = { onClear(); onDismiss() },
                    ) {
                        Txt(stringResource(R.string.clear), 14.sp, modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
            Box(Modifier.weight(1f).padding(top = 8.dp)) {
                AppGrid(apps, stringResource(R.string.empty_list)) { onPick(it); onDismiss() }
            }
        }
    }
}

/** قائمة خيارات بسيطة */
@Composable
fun MenuDialog(title: String, items: List<Pair<String, () -> Unit>>, onDismiss: () -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.4f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xF2101739))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Txt(title, 18.sp, weight = FontWeight.Bold)
            items.forEachIndexed { i, (label, action) ->
                TvCard(
                    Modifier.fillMaxWidth().height(40.dp),
                    focusRequester = if (i == 0) fr else null,
                    onClick = { action(); onDismiss() },
                ) {
                    Txt(label, 15.sp, modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 14.dp))
                }
            }
        }
    }
}

/** قائمة اختيار طويلة (المدن) */
@Composable
fun ListDialog(
    title: String,
    entries: List<Pair<String, Boolean>>,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.42f)
                .fillMaxHeight(0.86f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xF2101739))
                .padding(16.dp),
        ) {
            Txt(title, 18.sp, weight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(entries.size) { i ->
                    val (label, selected) = entries[i]
                    TvCard(
                        Modifier.fillMaxWidth().height(38.dp),
                        focusRequester = if (i == 0) fr else null,
                        background = if (selected) solid(Color(0x55FFC83D)) else FlatPanel,
                        onClick = { onPick(i); onDismiss() },
                    ) {
                        Txt(label, 15.sp, modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 14.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun contextOf() = LocalContext.current

@Suppress("unused")
private fun keepImports(d: Dp) = d
