package com.flancher.tv

import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ helpers

private fun weatherIcon(code: Int): ImageVector = when (code) {
    0, 1 -> Icons.Filled.WbSunny
    2, 3, 45, 48 -> Icons.Filled.Cloud
    in 51..67, in 80..82 -> Icons.Filled.WaterDrop
    in 71..77, 85, 86 -> Icons.Filled.AcUnit
    in 95..99 -> Icons.Filled.Thunderstorm
    else -> Icons.Filled.Cloud
}

@Composable
private fun weatherLabel(code: Int): String = stringResource(
    when (code) {
        0, 1 -> R.string.w_clear
        2, 3 -> R.string.w_cloudy
        45, 48 -> R.string.w_fog
        in 51..67, in 80..82 -> R.string.w_rain
        in 71..77, 85, 86 -> R.string.w_snow
        in 95..99 -> R.string.w_storm
        else -> R.string.w_cloudy
    }
)

private fun toMinutes(hhmm: String): Int {
    val p = hhmm.split(":")
    return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
}

/** (اسم الصلاة، وقتها) التالية */
@Composable
fun nextPrayer(p: PrayerTimes?, nowMin: Int): Pair<String, String>? {
    if (p == null) return null
    val list = listOf(
        stringResource(R.string.fajr) to p.fajr,
        stringResource(R.string.dhuhr) to p.dhuhr,
        stringResource(R.string.asr) to p.asr,
        stringResource(R.string.maghrib) to p.maghrib,
        stringResource(R.string.isha) to p.isha,
    )
    return list.firstOrNull { toMinutes(it.second) > nowMin } ?: list.first()
}

// ------------------------------------------------------------------ shell

@Composable
fun MainShell(st: LauncherState) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 10.dp)) {
        TopBar(st)
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            when (st.tab) {
                Tab.Home -> HomeBody(st)
                Tab.Apps -> AppsBody(st)
                Tab.Content -> ContentBody(st)
                Tab.Favorites -> FavoritesBody(st)
                Tab.History -> HistoryBody(st)
            }
        }
        BottomBar(st)
    }
}

@Composable
fun TopBar(st: LauncherState) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(10_000)
        }
    }
    val locale = if (st.lang == "ar") Locale.forLanguageTag("ar-u-nu-latn") else Locale(st.lang)
    val date = SimpleDateFormat("EEEE dd MMMM yyyy", locale).format(Date(now))
    val clock = SimpleDateFormat("HH:mm", Locale.US).format(Date(now))
    val w = st.weather

    Row(
        Modifier.fillMaxWidth().height(40.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBtn(Icons.Filled.Settings, stringResource(R.string.settings)) { st.overlay = Overlay.Settings }
        VDivider()
        IconBtn(Icons.Filled.Search, stringResource(R.string.search)) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_ASSIST).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                st.tab = Tab.Apps
            }
        }
        VDivider()
        Txt(date, 14.sp)
        Spacer(Modifier.weight(1f))

        // المدينة
        TvCard(
            Modifier.height(32.dp),
            shape = RoundedCornerShape(16.dp),
            background = solid(Color.Transparent),
            onClick = { st.showCityDialog = true },
        ) {
            Row(Modifier.padding(horizontal = 10.dp).fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocationOn, null, tint = Color(0xFF29B6F6), modifier = Modifier.size(20.dp))
                Txt(st.city.name(st.lang), 14.sp, modifier = Modifier.padding(horizontal = 4.dp))
                Icon(Icons.Filled.ArrowDropDown, null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
        VDivider()
        // الطقس
        if (w != null) {
            Icon(weatherIcon(w.code), null, tint = Gold, modifier = Modifier.size(26.dp))
            Column(Modifier.padding(horizontal = 6.dp)) {
                Txt("${w.tempC}°C", 15.sp, weight = FontWeight.Bold)
                Txt(weatherLabel(w.code), 10.sp, color = Color.White.copy(alpha = 0.8f))
            }
        } else {
            Txt("--°C", 15.sp)
        }
        VDivider()
        Icon(Icons.Filled.VerifiedUser, null, tint = Color(0xFF3DDC84), modifier = Modifier.size(24.dp))
        Txt(stringResource(R.string.device_protected), 11.sp, modifier = Modifier.padding(horizontal = 6.dp))
        VDivider()
        Txt(clock, 26.sp, weight = FontWeight.Bold)
    }
}

@Composable
fun BottomBar(st: LauncherState) {
    val tabs = listOf(
        Triple(Tab.Home, Icons.Filled.Home, R.string.nav_home),
        Triple(Tab.Apps, Icons.Filled.Apps, R.string.nav_apps),
        Triple(Tab.Content, Icons.Filled.Tv, R.string.nav_content),
        Triple(Tab.Favorites, Icons.Filled.Star, R.string.nav_favorites),
        Triple(Tab.History, Icons.Filled.History, R.string.nav_history),
    )
    Row(Modifier.fillMaxWidth().height(50.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier
                .weight(3.3f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(25.dp))
                .background(Color(0x990B1238)),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEach { (tab, icon, label) ->
                val selected = st.tab == tab
                TvCard(
                    Modifier.weight(1f).fillMaxHeight().padding(3.dp),
                    shape = RoundedCornerShape(22.dp),
                    background = if (selected) Brush.verticalGradient(listOf(Color(0x552B7BFF), Color(0x222B7BFF)))
                    else solid(Color.Transparent),
                    onClick = { st.tab = tab },
                ) {
                    Column(
                        Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(icon, null, tint = if (selected) Gold else Color.White, modifier = Modifier.size(20.dp))
                        Txt(
                            stringResource(label), 11.sp,
                            color = if (selected) Gold else Color.White,
                            weight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
        Row(
            Modifier
                .weight(1.5f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(25.dp))
                .background(Color(0x990B1238))
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Txt(stringResource(R.string.welcome_title), 12.sp, weight = FontWeight.Bold)
                Txt(stringResource(R.string.welcome_sub), 10.sp, color = Color.White.copy(alpha = 0.75f))
            }
            Icon(Icons.Filled.Android, null, tint = Color(0xFF3DDC84), modifier = Modifier.size(30.dp))
        }
    }
}

// ------------------------------------------------------------------ home

@Composable
fun HomeBody(st: LauncherState) {
    val bannerFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { bannerFocus.requestFocus() } }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        QuranBanner(
            Modifier.fillMaxWidth(0.6f).weight(3.2f).align(Alignment.CenterHorizontally),
            st,
            bannerFocus,
        )
        ShortcutsRow(Modifier.fillMaxWidth().weight(1.8f), st)
        CardsRow(Modifier.fillMaxWidth().weight(1.6f), st)
    }
}

@Composable
fun QuranBanner(modifier: Modifier, st: LauncherState, fr: FocusRequester) {
    TvCard(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        background = Brush.horizontalGradient(listOf(Color(0xFF1B1204), Color(0xFF3A2606), Color(0xFF120C03))),
        focusRequester = fr,
        onClick = { st.overlay = Overlay.Quran },
    ) {
        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1.15f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                Txt(stringResource(R.string.quran_title), 32.sp, color = Gold, weight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt(stringResource(R.string.listen_now), 22.sp, weight = FontWeight.Bold)
                    Box(
                        Modifier.padding(horizontal = 12.dp).size(42.dp).clip(CircleShape)
                            .background(Color(0x33FFC83D)),
                    ) {
                        Icon(
                            if (QuranPlayer.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(28.dp),
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().height(32.dp).clip(RoundedCornerShape(16.dp))
                        .background(Color(0x66000000)).padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val label = if (QuranPlayer.reciter != null)
                        "${st.surahName(QuranPlayer.surah)} • ${QuranPlayer.reciter!!.name}"
                    else stringResource(R.string.now_playing_none)
                    Txt(label, 13.sp, modifier = Modifier.weight(1f))
                    Icon(
                        Icons.Filled.Equalizer, null,
                        tint = if (QuranPlayer.isPlaying) Gold else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            Box(
                Modifier.weight(0.85f).fillMaxHeight().clip(RoundedCornerShape(14.dp)).background(
                    Brush.radialGradient(listOf(Color(0xFF8A5A12), Color(0xFF2A1A05)))
                ),
            ) {
                Icon(Icons.Filled.MenuBook, null, tint = Gold, modifier = Modifier.align(Alignment.Center).size(72.dp))
            }
        }
    }
}

@Composable
fun ShortcutsRow(modifier: Modifier, st: LauncherState) {
    val ctx = LocalContext.current
    val pinnedApps = st.pinned.mapNotNull { st.app(it) }.distinctBy { it.pkg }

    LazyRow(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(pinnedApps, key = { it.pkg }) { app ->
            TvCard(
                Modifier.width(112.dp).fillMaxHeight(),
                background = solid(Color(0xFFF1F3F8)),
                onLongClick = { st.actionApp = app.pkg },
                onClick = { st.launch(app.pkg) },
            ) {
                Column(
                    Modifier.fillMaxSize().padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    if (app.icon != null) Image(app.icon, null, Modifier.size(46.dp), contentScale = ContentScale.Fit)
                    Txt(app.label, 12.sp, color = Color(0xFF202124), weight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        item {
            ShortcutTile(Icons.Filled.MenuBook, R.string.quran_short,
                Brush.verticalGradient(listOf(Color(0xFF2E9E4F), Color(0xFF0F5A2A)))) { st.overlay = Overlay.Quran }
        }
        item {
            ShortcutTile(Icons.Filled.Headphones, R.string.listen_short,
                Brush.verticalGradient(listOf(Color(0xFF16275F), Color(0xFF0A1236)))) { st.listenNow() }
        }
        item {
            ShortcutTile(Icons.Filled.WbSunny, R.string.weather,
                Brush.verticalGradient(listOf(Color(0xFF2A7DE1), Color(0xFF0B3F9E)))) { st.showCityDialog = true }
        }
        item {
            ShortcutTile(Icons.Filled.Security, R.string.security,
                Brush.verticalGradient(listOf(Color(0xFF6B3FD1), Color(0xFF38207F)))) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e2: Exception) {
                        Toast.makeText(ctx, R.string.app_not_installed, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        item {
            ShortcutTile(Icons.Filled.Add, R.string.add_app,
                Brush.verticalGradient(listOf(Color(0xFF8C919B), Color(0xFF555A64)))) { st.picker = PickerTarget.Pin }
        }
    }
}

@Composable
private fun ShortcutTile(icon: ImageVector, label: Int, brush: Brush, onClick: () -> Unit) {
    TvCard(Modifier.width(112.dp).fillMaxHeight(), background = brush, onClick = onClick) {
        Column(
            Modifier.fillMaxSize().padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(40.dp))
            Txt(stringResource(label), 13.sp, weight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/** تشغيل التطبيق المرتبط بالبطاقة أو اختيار واحد إن لم يوجد */
private fun openAssigned(st: LauncherState, pkg: String, target: PickerTarget, ctx: android.content.Context) {
    if (pkg.isEmpty() || st.app(pkg) == null) {
        if (pkg.isNotEmpty()) Toast.makeText(ctx, R.string.app_not_installed, Toast.LENGTH_SHORT).show()
        st.picker = target
    } else {
        st.launch(pkg)
    }
}

@Composable
fun CardsRow(modifier: Modifier, st: LauncherState) {
    val ctx = LocalContext.current
    val cal = Calendar.getInstance()
    val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    val next = nextPrayer(st.prayers, nowMin)

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MoviesCard(Modifier.weight(1f).fillMaxHeight(), st) { openAssigned(st, st.moviesApp, PickerTarget.Movies, ctx) }
        LiveCard(Modifier.weight(1f).fillMaxHeight(), st) { openAssigned(st, st.liveApp, PickerTarget.Live, ctx) }
        WideCard(
            Modifier.weight(1.4f).fillMaxHeight(),
            Icons.Filled.AccessTime,
            stringResource(R.string.prayer_times),
            if (next != null) "${next.first}  ${next.second}" else stringResource(R.string.on_time),
            Brush.horizontalGradient(listOf(Color(0xCC2A2F7A), Color(0xCC121A4A))),
        ) { st.showPrayerDialog = true }
    }
}

@Composable
fun MoviesCard(modifier: Modifier, st: LauncherState, onClick: () -> Unit) {
    val app = st.app(st.moviesApp)
    WideCard(
        modifier, Icons.Filled.Movie,
        stringResource(R.string.movies_series),
        app?.label ?: stringResource(R.string.enjoy_watching),
        Brush.horizontalGradient(listOf(Color(0xCC5A2A8A), Color(0xCC1B1550))),
        onLongClick = { st.picker = PickerTarget.Movies },
        onClick = onClick,
    )
}

@Composable
fun LiveCard(modifier: Modifier, st: LauncherState, onClick: () -> Unit) {
    val app = st.app(st.liveApp)
    WideCard(
        modifier, Icons.Filled.LiveTv,
        stringResource(R.string.live_tv),
        app?.label ?: stringResource(R.string.various_channels),
        Brush.horizontalGradient(listOf(Color(0xCC1F4E9E), Color(0xCC111B52))),
        onLongClick = { st.picker = PickerTarget.Live },
        onClick = onClick,
    )
}
