package com.flancher.tv

import android.content.Context
import android.content.SharedPreferences

/** كل إعدادات اللانشر / tous les réglages / all launcher settings */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("flancher", Context.MODE_PRIVATE)

    /** system | ar | fr | en */
    var language: String
        get() = sp.getString("lang", "system") ?: "system"
        set(v) = sp.edit().putString("lang", v).apply()

    /** "preset:<key>" أو "custom" */
    var wallpaper: String
        get() = sp.getString("wallpaper", "preset:sunset") ?: "preset:sunset"
        set(v) = sp.edit().putString("wallpaper", v).apply()

    var wallpaperVersion: Int
        get() = sp.getInt("wallpaper_v", 0)
        set(v) = sp.edit().putInt("wallpaper_v", v).apply()

    var city: String
        get() = sp.getString("city", "algiers") ?: "algiers"
        set(v) = sp.edit().putString("city", v).apply()

    /** التطبيق المرتبط ببطاقة البث المباشر */
    var liveApp: String
        get() = sp.getString("live_app", "") ?: ""
        set(v) = sp.edit().putString("live_app", v).apply()

    /** التطبيق المرتبط ببطاقة الأفلام والمسلسلات */
    var moviesApp: String
        get() = sp.getString("movies_app", "") ?: ""
        set(v) = sp.edit().putString("movies_app", v).apply()

    var pinned: List<String>
        get() = getList("pinned", DEFAULT_PINNED)
        set(v) = setList("pinned", v)

    var favorites: List<String>
        get() = getList("favorites", emptyList())
        set(v) = setList("favorites", v)

    var history: List<String>
        get() = getList("history", emptyList())
        set(v) = setList("history", v)

    var lastReciterId: Int
        get() = sp.getInt("last_reciter", -1)
        set(v) = sp.edit().putInt("last_reciter", v).apply()

    var lastSurah: Int
        get() = sp.getInt("last_surah", 18)
        set(v) = sp.edit().putInt("last_surah", v).apply()

    private fun getList(key: String, default: List<String>): List<String> {
        if (!sp.contains(key)) return default
        val s = sp.getString(key, "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split(",")
    }

    private fun setList(key: String, v: List<String>) {
        sp.edit().putString(key, v.joinToString(",")).apply()
    }

    companion object {
        val DEFAULT_PINNED = listOf(
            "com.google.android.youtube.tv",
            "com.android.vending",
        )
    }
}
