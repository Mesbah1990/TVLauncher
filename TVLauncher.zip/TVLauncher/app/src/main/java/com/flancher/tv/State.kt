package com.flancher.tv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class AppInfo(val pkg: String, val label: String, val icon: ImageBitmap?)

enum class Tab { Home, Apps, Content, Favorites, History }
enum class Overlay { None, Quran, Settings }
enum class PickerTarget { Live, Movies, Pin }

const val YT_TV = "com.google.android.youtube.tv"
const val YT = "com.google.android.youtube"

class LauncherState(val ctx: Context) {
    val prefs = Prefs(ctx)

    // ---- navigation / dialogs ----
    var tab by mutableStateOf(Tab.Home)
    var overlay by mutableStateOf(Overlay.None)
    var picker by mutableStateOf<PickerTarget?>(null)
    var actionApp by mutableStateOf<String?>(null)
    var showCityDialog by mutableStateOf(false)
    var showPrayerDialog by mutableStateOf(false)
    var appsTick by mutableIntStateOf(0)

    // ---- settings ----
    var langPref by mutableStateOf(prefs.language)
    var wallpaper by mutableStateOf(prefs.wallpaper)
    var wallpaperVersion by mutableIntStateOf(prefs.wallpaperVersion)
    var wallpaperBitmap by mutableStateOf<ImageBitmap?>(null)
    var cityKey by mutableStateOf(prefs.city)
    var liveApp by mutableStateOf(prefs.liveApp)
    var moviesApp by mutableStateOf(prefs.moviesApp)
    var pinned by mutableStateOf(prefs.pinned)
    var favorites by mutableStateOf(prefs.favorites)
    var history by mutableStateOf(prefs.history)

    // ---- data ----
    var apps by mutableStateOf<List<AppInfo>>(emptyList())
    var weather by mutableStateOf<WeatherInfo?>(null)
    var prayers by mutableStateOf<PrayerTimes?>(null)
    var reciters by mutableStateOf<List<Reciter>>(emptyList())
    var surahNames by mutableStateOf(SURAH_NAMES_AR)
    var quranLoading by mutableStateOf(false)
    var quranOffline by mutableStateOf(false)

    val lang: String
        get() = if (langPref == "system") {
            Locale.getDefault().language.let { if (it == "ar" || it == "fr") it else "en" }
        } else langPref

    val city: City get() = cityByKey(cityKey)

    // ---------------- apps ----------------
    fun resolve(pkg: String): String =
        if (pkg == YT_TV && apps.none { it.pkg == YT_TV } && apps.any { it.pkg == YT }) YT else pkg

    fun app(pkg: String): AppInfo? {
        if (pkg.isEmpty()) return null
        val p = resolve(pkg)
        return apps.firstOrNull { it.pkg == p }
    }

    suspend fun refreshApps() = withContext(Dispatchers.Default) {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppInfo>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(i, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString()
                val icon = try {
                    ri.loadIcon(pm).toBitmap(160, 160, Bitmap.Config.ARGB_8888).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
                out.add(AppInfo(pkg, label, icon))
            }
        }
        out.sortBy { it.label.lowercase() }
        apps = out
    }

    fun launch(pkg: String): Boolean {
        val p = resolve(pkg)
        val pm = ctx.packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            history = (listOf(p) + history.filter { it != p }).take(24)
            prefs.history = history
            true
        } catch (e: Exception) {
            false
        }
    }

    fun togglePinned(pkg: String) {
        pinned = if (pkg in pinned) pinned - pkg else pinned + pkg
        prefs.pinned = pinned
    }

    fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        prefs.favorites = favorites
    }

    fun clearHistory() {
        history = emptyList()
        prefs.history = history
    }

    fun assign(target: PickerTarget, pkg: String) {
        when (target) {
            PickerTarget.Live -> { liveApp = pkg; prefs.liveApp = pkg }
            PickerTarget.Movies -> { moviesApp = pkg; prefs.moviesApp = pkg }
            PickerTarget.Pin -> if (pkg.isNotEmpty() && pkg !in pinned) togglePinned(pkg)
        }
    }

    // ---------------- settings ----------------
    fun setLanguage(l: String, activity: Activity) {
        if (l == langPref) return
        prefs.language = l
        langPref = l
        activity.recreate()
    }

    fun setCity(key: String) {
        cityKey = key
        prefs.city = key
    }

    fun setWallpaperPreset(key: String) {
        wallpaper = "preset:$key"
        prefs.wallpaper = wallpaper
    }

    fun resetWallpaper() {
        setWallpaperPreset("sunset")
    }

    private fun wallpaperFile() = File(ctx.filesDir, "wallpaper.jpg")

    suspend fun setCustomWallpaper(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2560 || bounds.outHeight / sample > 1440) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return@withContext false
            wallpaperFile().outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            prefs.wallpaperVersion = prefs.wallpaperVersion + 1
            wallpaperVersion = prefs.wallpaperVersion
            prefs.wallpaper = "custom"
            wallpaper = "custom"
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun loadWallpaperBitmap() = withContext(Dispatchers.IO) {
        if (wallpaper != "custom") {
            wallpaperBitmap = null
            return@withContext
        }
        val f = wallpaperFile()
        wallpaperBitmap = if (f.exists()) {
            BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } else null
        if (wallpaperBitmap == null) {
            wallpaper = "preset:sunset"
            prefs.wallpaper = wallpaper
        }
    }

    // ---------------- weather / prayers ----------------
    suspend fun refreshWeather() {
        Net.weather(city)?.let { weather = it }
    }

    suspend fun refreshPrayers() {
        Net.prayerTimes(city)?.let { prayers = it }
    }

    // ---------------- Quran ----------------
    suspend fun loadQuranData() {
        quranLoading = true
        val l = lang
        val list = Net.reciters(l)
        if (list != null) {
            reciters = list
            quranOffline = false
        } else if (reciters.isEmpty()) {
            reciters = FALLBACK_RECITERS
            quranOffline = true
        }
        Net.surahNames(l)?.let { surahNames = it }
        quranLoading = false
    }

    fun featuredReciters(): List<Reciter> {
        val out = ArrayList<Reciter>()
        for (keys in FEATURED_KEYWORDS) {
            val r = reciters.firstOrNull { rc ->
                val n = rc.name.lowercase()
                keys.any { n.contains(it.lowercase()) }
            }
            if (r != null && r !in out) out.add(r)
        }
        return out
    }

    fun defaultReciter(): Reciter? =
        reciters.firstOrNull { it.id == prefs.lastReciterId }
            ?: featuredReciters().firstOrNull()
            ?: reciters.firstOrNull()

    fun surahName(n: Int): String = surahNames.getOrNull(n - 1) ?: SURAH_NAMES_AR.getOrNull(n - 1) ?: "$n"

    /** زر "استمع الآن" */
    fun listenNow() {
        if (QuranPlayer.reciter != null) {
            QuranPlayer.toggle()
            return
        }
        val r = defaultReciter() ?: return
        val s = prefs.lastSurah.takeIf { it in r.surahs } ?: r.surahs.first()
        QuranPlayer.play(r, s)
    }
}
