package com.flancher.tv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WeatherInfo(val tempC: Int, val code: Int)

data class PrayerTimes(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
) {
    fun asList() = listOf(fajr, sunrise, dhuhr, asr, maghrib, isha)
}

object Net {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "Flancher/1.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** الطقس من Open-Meteo (بدون مفتاح) */
    suspend fun weather(city: City): WeatherInfo? = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}" +
                "&current=temperature_2m,weather_code"
            val cur = JSONObject(get(url)).getJSONObject("current")
            WeatherInfo(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"))
        } catch (e: Exception) {
            null
        }
    }

    /** مواقيت الصلاة من Aladhan */
    suspend fun prayerTimes(city: City): PrayerTimes? = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.aladhan.com/v1/timings?latitude=${city.lat}&longitude=${city.lon}&method=${city.method}"
            val t = JSONObject(get(url)).getJSONObject("data").getJSONObject("timings")
            fun h(k: String) = t.getString(k).take(5)
            PrayerTimes(h("Fajr"), h("Sunrise"), h("Dhuhr"), h("Asr"), h("Maghrib"), h("Isha"))
        } catch (e: Exception) {
            null
        }
    }

    private fun apiLang(lang: String) = when (lang) {
        "fr" -> "fr"
        "en" -> "eng"
        else -> "ar"
    }

    /** قائمة القرّاء من mp3quran.net */
    suspend fun reciters(lang: String): List<Reciter>? = withContext(Dispatchers.IO) {
        try {
            val arr = JSONObject(get("https://www.mp3quran.net/api/v3/reciters?language=${apiLang(lang)}"))
                .getJSONArray("reciters")
            val out = ArrayList<Reciter>()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val moshafs = r.optJSONArray("moshaf") ?: continue
                var best: Reciter? = null
                for (j in 0 until moshafs.length()) {
                    val m = moshafs.getJSONObject(j)
                    var server = m.optString("server")
                    if (server.isBlank()) continue
                    if (!server.endsWith("/")) server += "/"
                    val list = m.optString("surah_list").split(",")
                        .mapNotNull { it.trim().toIntOrNull() }
                        .filter { it in 1..114 }
                    if (list.isEmpty()) continue
                    if (best == null || list.size > best.surahs.size) {
                        best = Reciter(r.getInt("id"), r.getString("name"), server, list)
                    }
                }
                if (best != null) out.add(best)
            }
            if (out.isEmpty()) null else out
        } catch (e: Exception) {
            null
        }
    }

    /** أسماء السور باللغة المختارة */
    suspend fun surahNames(lang: String): List<String>? = withContext(Dispatchers.IO) {
        if (lang == "ar") return@withContext SURAH_NAMES_AR
        try {
            val arr = JSONObject(get("https://www.mp3quran.net/api/v3/suwar?language=${apiLang(lang)}"))
                .getJSONArray("suwar")
            val names = Array(114) { SURAH_NAMES_AR[it] }
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val id = s.getInt("id")
                if (id in 1..114) names[id - 1] = s.getString("name")
            }
            names.toList()
        } catch (e: Exception) {
            null
        }
    }
}

fun surahUrl(r: Reciter, surah: Int): String = r.server + String.format("%03d.mp3", surah)
