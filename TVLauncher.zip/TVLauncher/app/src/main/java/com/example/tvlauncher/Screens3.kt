package com.example.tvlauncher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class SysItem(val icon: ImageVector, val key: String, val action: String)

private val SYS_ITEMS = listOf(
    SysItem(Icons.Filled.Wifi, "ts_wifi", Settings.ACTION_WIFI_SETTINGS),
    SysItem(Icons.Filled.Language, "ts_network", Settings.ACTION_WIRELESS_SETTINGS),
    SysItem(Icons.Filled.Tv, "ts_display", Settings.ACTION_DISPLAY_SETTINGS),
    SysItem(Icons.Filled.HighQuality, "ts_modes", "app:modes"),
    SysItem(Icons.Filled.VolumeUp, "ts_sound", Settings.ACTION_SOUND_SETTINGS),
    SysItem(Icons.Filled.Code, "ts_dev", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
    SysItem(Icons.Filled.Apps, "ts_apps", Settings.ACTION_APPLICATION_SETTINGS),
    SysItem(Icons.Filled.Widgets, "ts_allapps", Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
    SysItem(Icons.Filled.Lock, "ts_security", Settings.ACTION_SECURITY_SETTINGS),
    SysItem(Icons.Filled.Storage, "ts_storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
    SysItem(Icons.Filled.Schedule, "ts_date", Settings.ACTION_DATE_SETTINGS),
    SysItem(Icons.Filled.Translate, "ts_lang", Settings.ACTION_LOCALE_SETTINGS),
    SysItem(Icons.Filled.Keyboard, "ts_keyboard", Settings.ACTION_INPUT_METHOD_SETTINGS),
    SysItem(Icons.Filled.Bluetooth, "ts_bt", Settings.ACTION_BLUETOOTH_SETTINGS),
    SysItem(Icons.Filled.Accessibility, "ts_access", Settings.ACTION_ACCESSIBILITY_SETTINGS),
    SysItem(Icons.Filled.Home, "ts_home", Settings.ACTION_HOME_SETTINGS),
    SysItem(Icons.Filled.Cast, "ts_cast", Settings.ACTION_CAST_SETTINGS),
    SysItem(Icons.Filled.Info, "ts_about", Settings.ACTION_DEVICE_INFO_SETTINGS),
    SysItem(Icons.Filled.Settings, "ts_all", Settings.ACTION_SETTINGS),
)

@Composable
fun TvSettingsScreen(ui: UiState) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FocusCard({ ui.screen = Screen.Home }, Modifier.size(42.dp), CircleShape) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            Icon(Icons.Filled.SettingsApplications, null, tint = Gold, modifier = Modifier.size(28.dp))
            Text(t("tv_settings"), color = Color.White, fontSize = 26.sp)
        }

        Row(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            // system shortcuts
            LazyVerticalGrid(
                GridCells.Fixed(3), Modifier.weight(1.5f).fillMaxHeight(),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(SYS_ITEMS.size) { i ->
                    val it = SYS_ITEMS[i]
                    FocusCard(
                        {
                            if (it.action == "app:modes") ui.dialog = Dlg.DisplayModes
                            else openSystem(ctx, it.action)
                        },
                        Modifier.fillMaxWidth().height(86.dp), RoundedCornerShape(14.dp),
                        SolidColor(Glass), if (i == 0) first else null,
                    ) {
                        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(it.icon, null, tint = Gold, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.height(4.dp))
                            Text(t(it.key), color = Color.White, fontSize = 14.sp, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            // remote + startup + info
            Column(Modifier.weight(1.2f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                RemoteSection(ui)
                StartupSection(ui)
                DeviceInfoSection()
            }
        }
    }
}

@Composable
fun RemoteSection(ui: UiState) {
    val ctx = LocalContext.current
    val prefs = ui.prefs
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Look.remote) { tick++ }
    Section(t("phone_remote")) {
        Toggle(t("remote_on"), Look.remote) {
            Look.set("remote", it)
            if (it) Remote.start(ctx.applicationContext as android.app.Application) else Remote.stop()
            tick++
        }
        if (Look.remote) {
            val ip = remember(tick) { Remote.localIp() }
            val port = if (Remote.port == 0) 8080 else Remote.port
            Text(t("remote_open"), color = Color(0xCCFFFFFF), fontSize = 14.sp)
            Text(if (ip.isEmpty()) t("no_ip") else "http://" + ip + ":" + port, color = Gold, fontSize = 22.sp)
            Text(t("remote_pin") + ":  " + prefs.remotePin, color = Color.White, fontSize = 22.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(t("remote_new_pin"), false) { prefs.regeneratePin() }
                Chip(t("remote_forget") + " (" + prefs.pairedCount + ")", false) { prefs.clearTokens() }
            }
            Text(t("remote_hint"), color = Color(0x99FFFFFF), fontSize = 12.sp)
            Chip(t("acc_enable"), RemoteAccessibilityService.instance != null) { openSystem(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            Text(t("acc_note"), color = Color(0x99FFFFFF), fontSize = 12.sp)
        }
    }
}

@Composable
fun StartupSection(ui: UiState) {
    val ctx = LocalContext.current
    Section(t("startup")) {
        Toggle(t("autostart"), Look.autostart) { Look.set("autostart", it) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(t("overlay_perm"), Settings.canDrawOverlays(ctx)) {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) { openSystem(ctx, Settings.ACTION_SETTINGS) }
            }
            Chip(t("default_launcher"), false) { openSystem(ctx, Settings.ACTION_HOME_SETTINGS) }
        }
        Text(t("hint_home"), color = Color(0x99FFFFFF), fontSize = 12.sp)
    }
}

@Suppress("DEPRECATION")
fun deviceInfo(ctx: Context): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    out.add("di_model" to Build.MODEL)
    out.add("di_brand" to Build.MANUFACTURER)
    out.add("di_android" to (Build.VERSION.RELEASE + "  (API " + Build.VERSION.SDK_INT + ")"))
    try {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = wm.defaultDisplay
        val m = android.util.DisplayMetrics()
        d.getRealMetrics(m)
        out.add("di_screen" to (m.widthPixels.toString() + " x " + m.heightPixels + "  " + Math.round(d.refreshRate) + " Hz  " + m.densityDpi + " dpi"))
    } catch (_: Exception) {}
    val ip = Remote.localIp()
    val kind = netKind(ctx)
    out.add("di_net" to (when (kind) { 1 -> "Wi-Fi"; 2 -> "Ethernet"; 3 -> "?"; else -> "-" } + (if (ip.isNotEmpty()) "   " + ip else "")))
    try {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        out.add("di_ram" to (gb(mi.availMem) + " / " + gb(mi.totalMem)))
    } catch (_: Exception) {}
    try {
        val st = StatFs(Environment.getDataDirectory().path)
        out.add("di_storage" to (gb(st.availableBytes) + " / " + gb(st.totalBytes)))
    } catch (_: Exception) {}
    return out
}

private fun gb(b: Long) = String.format(java.util.Locale.US, "%.1f GB", b / 1073741824.0)

@Composable
fun DeviceInfoSection() {
    val ctx = LocalContext.current
    val info = remember { deviceInfo(ctx) }
    Section(t("device_info")) {
        info.forEach { (k, v) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t(k), color = Color(0xAAFFFFFF), fontSize = 14.sp, modifier = Modifier.weight(0.8f))
                Text(v, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1.4f))
            }
        }
    }
}

@Suppress("DEPRECATION")
@Composable
fun DisplayModesDialog(ui: UiState) {
    val ctx = LocalContext.current
    val modes = remember {
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val d = wm.defaultDisplay
            val cur = d.mode.modeId
            d.supportedModes.map {
                val s = it.physicalWidth.toString() + " x " + it.physicalHeight + "  @ " + Math.round(it.refreshRate) + " Hz"
                (if (it.modeId == cur) "● " else "   ") + s
            }
        } catch (_: Exception) { emptyList() }
    }
    TvDialog(t("display_modes"), { ui.dialog = null }, scroll = true) {
        modes.forEach { Text(it, color = Color.White, fontSize = 17.sp) }
        Text(t("current_mode"), color = Color(0x99FFFFFF), fontSize = 12.sp)
        DialogButton(t("ts_display"), { openSystem(ctx, Settings.ACTION_DISPLAY_SETTINGS); ui.dialog = null })
        DialogButton(t("back"), { ui.dialog = null })
    }
}
