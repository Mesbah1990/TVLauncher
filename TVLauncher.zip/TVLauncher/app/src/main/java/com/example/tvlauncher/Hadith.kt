package com.example.tvlauncher

class Hadith(val ar: String, val en: String, val fr: String, val src: String) {
    fun text(l: Lang) = when (l) { Lang.AR -> ar; Lang.EN -> en; Lang.FR -> fr }
    fun source(l: Lang): String = SOURCES[src]?.let {
        when (l) { Lang.AR -> it[0]; Lang.EN -> it[1]; Lang.FR -> it[2] }
    } ?: ""

    companion object {
        private val SOURCES = mapOf(
            "bm" to listOf("متفق عليه", "Agreed upon (Bukhari & Muslim)", "Al-Bukhari et Muslim"),
            "b" to listOf("رواه البخاري", "Narrated by Al-Bukhari", "Rapporté par Al-Bukhari"),
            "m" to listOf("رواه مسلم", "Narrated by Muslim", "Rapporté par Muslim"),
            "t" to listOf("رواه الترمذي", "Narrated by At-Tirmidhi", "Rapporté par At-Tirmidhi"),
            "td" to listOf("رواه أبو داود والترمذي", "Narrated by Abu Dawud & At-Tirmidhi", "Rapporté par Abu Dawud et At-Tirmidhi"),
        )
    }
}

object Hadiths {
    val all = listOf(
        Hadith("إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى",
            "Actions are judged by intentions, and every person will get what they intended.",
            "Les actes ne valent que par les intentions, et chacun n'obtiendra que ce qu'il a eu l'intention de faire.", "bm"),
        Hadith("الدين النصيحة", "Religion is sincere advice.", "La religion, c'est le bon conseil sincère.", "m"),
        Hadith("لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه",
            "None of you truly believes until he loves for his brother what he loves for himself.",
            "Aucun de vous ne croit véritablement tant qu'il n'aime pas pour son frère ce qu'il aime pour lui-même.", "bm"),
        Hadith("من كان يؤمن بالله واليوم الآخر فليقل خيرًا أو ليصمت",
            "Whoever believes in Allah and the Last Day, let him speak good or remain silent.",
            "Que celui qui croit en Allah et au Jour dernier dise du bien ou se taise.", "bm"),
        Hadith("المسلم من سلم المسلمون من لسانه ويده",
            "A Muslim is the one from whose tongue and hand the Muslims are safe.",
            "Le musulman est celui dont les musulmans sont à l'abri de la langue et de la main.", "bm"),
        Hadith("الكلمة الطيبة صدقة", "A good word is charity.", "Une bonne parole est une aumône.", "bm"),
        Hadith("تبسمك في وجه أخيك لك صدقة", "Your smile in the face of your brother is charity.",
            "Ton sourire au visage de ton frère est une aumône.", "t"),
        Hadith("خيركم من تعلم القرآن وعلّمه", "The best among you are those who learn the Quran and teach it.",
            "Les meilleurs d'entre vous sont ceux qui apprennent le Coran et l'enseignent.", "b"),
        Hadith("من سلك طريقًا يلتمس فيه علمًا سهّل الله له به طريقًا إلى الجنة",
            "Whoever travels a path seeking knowledge, Allah makes easy for him a path to Paradise.",
            "Quiconque emprunte un chemin à la recherche du savoir, Allah lui facilite un chemin vers le Paradis.", "m"),
        Hadith("أحب الأعمال إلى الله أدومها وإن قلّ",
            "The most beloved deeds to Allah are the most consistent, even if small.",
            "Les actes les plus aimés d'Allah sont les plus réguliers, même s'ils sont minimes.", "bm"),
        Hadith("اتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن",
            "Fear Allah wherever you are, follow a bad deed with a good one to erase it, and treat people with good character.",
            "Crains Allah où que tu sois, fais suivre une mauvaise action d'une bonne qui l'effacera, et comporte-toi avec les gens avec un bon caractère.", "t"),
        Hadith("ليس الشديد بالصُّرَعة، إنما الشديد الذي يملك نفسه عند الغضب",
            "The strong person is not the one who overpowers others, but the one who controls himself in anger.",
            "Le fort n'est pas celui qui terrasse les autres, mais celui qui se maîtrise dans la colère.", "bm"),
        Hadith("من لا يرحم لا يُرحم", "He who shows no mercy will not be shown mercy.",
            "Celui qui n'a pas de miséricorde n'obtiendra pas de miséricorde.", "bm"),
        Hadith("الطهور شطر الإيمان", "Cleanliness is half of faith.", "La propreté est la moitié de la foi.", "m"),
        Hadith("كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن: سبحان الله وبحمده، سبحان الله العظيم",
            "Two words light on the tongue, heavy on the scale, beloved to the Most Merciful: Subhan Allahi wa bihamdihi, Subhan Allahil-Azim.",
            "Deux paroles légères sur la langue, lourdes dans la balance, aimées du Tout Miséricordieux : « Subhan Allah wa bihamdihi, Subhan Allahil-Azim ».", "bm"),
        Hadith("من قال: سبحان الله وبحمده، في يوم مائة مرة، حُطّت خطاياه وإن كانت مثل زبد البحر",
            "Whoever says 'Subhan Allahi wa bihamdihi' a hundred times a day, his sins are forgiven even if they are like the foam of the sea.",
            "Celui qui dit « Subhan Allah wa bihamdihi » cent fois par jour, ses péchés sont effacés même s'ils sont comme l'écume de la mer.", "bm"),
        Hadith("إن الله لا ينظر إلى صوركم وأموالكم، ولكن ينظر إلى قلوبكم وأعمالكم",
            "Allah does not look at your appearance or wealth, but He looks at your hearts and deeds.",
            "Allah ne regarde ni vos apparences ni vos biens, mais Il regarde vos cœurs et vos actes.", "m"),
        Hadith("لا تغضب", "Do not become angry.", "Ne te mets pas en colère.", "b"),
        Hadith("ما نقصت صدقة من مال", "Charity never decreases wealth.", "L'aumône ne diminue jamais les biens.", "m"),
        Hadith("الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء",
            "The Most Merciful shows mercy to the merciful. Be merciful to those on earth, and the One above the heavens will be merciful to you.",
            "Le Miséricordieux fait miséricorde aux miséricordieux. Soyez miséricordieux envers ceux qui sont sur terre, Celui qui est au ciel aura miséricorde de vous.", "td"),
        Hadith("من دلّ على خير فله مثل أجر فاعله", "Whoever guides to good will have a reward like the one who does it.",
            "Celui qui guide vers le bien a une récompense égale à celle de son auteur.", "m"),
        Hadith("البر حسن الخلق", "Righteousness is good character.", "La piété, c'est le bon comportement.", "m"),
        Hadith("أكمل المؤمنين إيمانًا أحسنهم خلقًا",
            "The believers with the most complete faith are those with the best character.",
            "Les croyants à la foi la plus complète sont ceux qui ont le meilleur caractère.", "td"),
        Hadith("من حسن إسلام المرء تركه ما لا يعنيه",
            "Part of a person's good Islam is leaving what does not concern him.",
            "Fait partie de la belle pratique de l'islam de délaisser ce qui ne nous concerne pas.", "t"),
        Hadith("إذا مات ابن آدم انقطع عمله إلا من ثلاث: صدقة جارية، أو علم يُنتفع به، أو ولد صالح يدعو له",
            "When a person dies, his deeds end except three: ongoing charity, beneficial knowledge, or a righteous child who prays for him.",
            "Quand le fils d'Adam meurt, ses œuvres s'interrompent sauf trois : une aumône continue, un savoir utile, ou un enfant pieux qui invoque pour lui.", "m"),
        Hadith("اتقوا النار ولو بشق تمرة", "Protect yourselves from the Fire, even with half a date.",
            "Préservez-vous du Feu, ne serait-ce qu'avec une demi-datte.", "bm"),
        Hadith("والصلاة نور", "Prayer is light.", "La prière est une lumière.", "m"),
        Hadith("أفشوا السلام بينكم", "Spread the greeting of peace among you.", "Propagez le salut entre vous.", "m"),
        Hadith("يسّروا ولا تعسّروا، وبشّروا ولا تنفّروا",
            "Make things easy and do not make them difficult; give glad tidings and do not drive people away.",
            "Facilitez et ne compliquez pas ; annoncez la bonne nouvelle et ne faites pas fuir.", "bm"),
        Hadith("الحياء من الإيمان", "Modesty is part of faith.", "La pudeur fait partie de la foi.", "bm"),
        Hadith("المؤمن للمؤمن كالبنيان يشد بعضه بعضًا",
            "The believers are like a building, each part strengthening the other.",
            "Le croyant est pour le croyant comme un édifice dont les parties se soutiennent.", "bm"),
        Hadith("كلكم راعٍ وكلكم مسؤول عن رعيته",
            "Each of you is a shepherd and each is responsible for his flock.",
            "Chacun de vous est un berger et chacun est responsable de son troupeau.", "bm"),
        Hadith("من صام رمضان إيمانًا واحتسابًا غُفر له ما تقدم من ذنبه",
            "Whoever fasts Ramadan out of faith and seeking reward, his previous sins are forgiven.",
            "Celui qui jeûne le Ramadan avec foi et en espérant la récompense, ses péchés passés lui sont pardonnés.", "bm"),
    )

    /** A different hadith every day by default. */
    fun todayIndex(): Int = (java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)) % all.size
}
