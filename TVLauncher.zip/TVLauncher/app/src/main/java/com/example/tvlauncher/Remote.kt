package com.example.tvlauncher

import android.accessibilityservice.AccessibilityService
import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.security.SecureRandom

/** Starts the launcher after the TV boots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (!Look.autostart) return
        try {
            ctx.startActivity(
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (_: Exception) {}
    }
}

/** Optional: lets the phone remote drive other apps (Back / Home / D-pad / OK). */
class RemoteAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { if (instance === this) instance = null; return super.onUnbind(intent) }

    fun press(key: String): Boolean {
        when (key) {
            "BACK" -> return performGlobalAction(GLOBAL_ACTION_BACK)
            "HOME" -> return performGlobalAction(GLOBAL_ACTION_HOME)
            "MENU" -> return performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
        val root = rootInActiveWindow ?: return false
        val cur = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
        if (key == "OK") return cur?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        val dir = when (key) {
            "UP" -> android.view.View.FOCUS_UP
            "DOWN" -> android.view.View.FOCUS_DOWN
            "LEFT" -> android.view.View.FOCUS_LEFT
            "RIGHT" -> android.view.View.FOCUS_RIGHT
            else -> return false
        }
        val next = (cur ?: root).focusSearch(dir) ?: return false
        return next.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    }

    companion object { @Volatile var instance: RemoteAccessibilityService? = null }
}

/**
 * Tiny HTTP server so a phone on the same Wi-Fi can open http://TV-IP:8080 and use it as a remote.
 * Protected by a 6-digit PIN shown on the TV; after pairing the phone gets a random token.
 */
object Remote {
    @Volatile private var server: ServerSocket? = null
    @Volatile var port = 0
        private set
    private val main = Handler(Looper.getMainLooper())
    private val rnd = SecureRandom()
    private var fails = 0
    private var lockUntil = 0L

    fun running() = server != null

    fun start(app: Application) {
        if (server != null) return
        Thread {
            var s: ServerSocket? = null
            for (p in 8080..8090) {
                try { s = ServerSocket(p); port = p; break } catch (_: Exception) {}
            }
            if (s == null) return@Thread
            server = s
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    Thread { handle(app, c) }.start()
                } catch (_: Exception) { break }
            }
            server = null
        }.start()
    }

    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: ""
                }
            }
        } catch (_: Exception) {}
        return ""
    }

    private fun isLan(c: Socket): Boolean {
        val a = c.inetAddress
        return a.isSiteLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress
    }

    private fun handle(app: Application, c: Socket) {
        try {
            c.soTimeout = 5000
            if (!isLan(c)) { c.close(); return }
            val rd = BufferedReader(InputStreamReader(c.getInputStream(), Charsets.UTF_8))
            val line = rd.readLine() ?: return
            while (true) { val h = rd.readLine() ?: break; if (h.isEmpty()) break }
            val parts = line.split(" ")
            if (parts.size < 2) return
            val target = parts[1]
            val path = target.substringBefore("?")
            val q = HashMap<String, String>()
            target.substringAfter("?", "").split("&").forEach {
                if (it.isNotEmpty()) {
                    val k = it.substringBefore("=")
                    val v = it.substringAfter("=", "")
                    q[k] = try { URLDecoder.decode(v, "UTF-8") } catch (_: Exception) { v }
                }
            }
            val out = c.getOutputStream()
            fun send(code: Int, type: String, body: String) {
                val b = body.toByteArray(Charsets.UTF_8)
                out.write(("HTTP/1.1 " + code + " OK\r\nContent-Type: " + type + "; charset=utf-8\r\nContent-Length: " + b.size +
                    "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray())
                out.write(b)
                out.flush()
            }
            val p = (app as App).prefs
            if (path == "/" || path == "/index.html") { send(200, "text/html", PAGE); return }
            if (path == "/api/pair") {
                val now = System.currentTimeMillis()
                synchronized(this) {
                    if (now < lockUntil) { send(429, "application/json", "{\"ok\":false,\"err\":\"locked\"}"); return }
                    val pin = q["pin"] ?: ""
                    if (pin.length == 6 && java.security.MessageDigest.isEqual(pin.toByteArray(), p.remotePin.toByteArray())) {
                        fails = 0
                        val tk = ByteArray(16).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }
                        main.post { p.addToken(tk) }
                        send(200, "application/json", "{\"ok\":true,\"token\":\"" + tk + "\"}")
                    } else {
                        fails++
                        if (fails >= 5) { fails = 0; lockUntil = now + 60_000 }
                        send(200, "application/json", "{\"ok\":false}")
                    }
                }
                return
            }
            if (!p.hasToken(q["t"] ?: "")) { send(401, "application/json", "{\"ok\":false,\"err\":\"auth\"}"); return }
            when (path) {
                "/api/key" -> { key(app, q["k"] ?: ""); send(200, "application/json", "{\"ok\":true}") }
                "/api/vol" -> {
                    val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val d = when (q["d"]) { "up" -> AudioManager.ADJUST_RAISE; "down" -> AudioManager.ADJUST_LOWER; else -> AudioManager.ADJUST_TOGGLE_MUTE }
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
                    send(200, "application/json", "{\"ok\":true}")
                }
                "/api/apps" -> {
                    val sb = StringBuilder("[")
                    Apps.list(app).forEachIndexed { i, a ->
                        if (i > 0) sb.append(',')
                        sb.append("{\"p\":\"").append(esc(a.pkg)).append("\",\"n\":\"").append(esc(a.label)).append("\"}")
                    }
                    sb.append("]")
                    send(200, "application/json", sb.toString())
                }
                "/api/launch" -> {
                    val pkg = q["p"] ?: ""
                    main.post { Apps.launch(app, pkg) }
                    send(200, "application/json", "{\"ok\":true}")
                }
                "/api/status" -> send(200, "application/json",
                    "{\"ok\":true,\"front\":" + (MainActivity.current != null) + ",\"acc\":" + (RemoteAccessibilityService.instance != null) + "}")
                else -> send(404, "application/json", "{\"ok\":false}")
            }
        } catch (_: Exception) {
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
    }

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun key(ctx: Context, k: String) {
        val code = when (k) {
            "UP" -> KeyEvent.KEYCODE_DPAD_UP
            "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
            "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT
            "RIGHT" -> KeyEvent.KEYCODE_DPAD_RIGHT
            "OK" -> KeyEvent.KEYCODE_DPAD_CENTER
            "BACK" -> KeyEvent.KEYCODE_BACK
            "MENU" -> KeyEvent.KEYCODE_MENU
            else -> return
        }
        val act = MainActivity.current
        if (act != null) {
            // launcher is in front: drive it directly
            if (k == "HOME") { main.post { Nav.homeTick++ }; return }
            act.sendKey(code)
            return
        }
        // another app is in front: needs the accessibility service
        val acc = RemoteAccessibilityService.instance
        if (k == "HOME" && acc == null) {
            main.post {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }
            return
        }
        acc?.press(k)
    }

    private val PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>TV Remote</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:#0b1220;color:#fff;font-family:system-ui,sans-serif;text-align:center;padding:14px}
button{background:#1d2a4a;color:#fff;border:0;border-radius:18px;font-size:22px;padding:0;height:72px;width:72px;margin:5px;touch-action:manipulation}
button:active{background:#4da3ff}
.w{width:104px;height:56px;font-size:17px}
input{font-size:28px;text-align:center;width:200px;padding:10px;border-radius:12px;border:0;letter-spacing:6px}
#apps button{width:46%;height:48px;font-size:14px;border-radius:12px;overflow:hidden}
.tabs button{width:44%;height:44px;font-size:16px}
#msg{color:#ffc83d;min-height:22px;font-size:14px}
</style></head><body>
<div id="pair"><h2>TV Remote</h2><p>PIN (Settings &gt; Phone remote)</p>
<input id="pin" inputmode="numeric" maxlength="6"><br><br><button class="w" onclick="pairNow()">OK</button></div>
<div id="main" style="display:none">
<div class="tabs"><button onclick="tab(0)">Remote</button><button onclick="tab(1)">Apps</button></div>
<div id="msg"></div>
<div id="rem">
<div><button class="w" onclick="k('BACK')">Back</button><button class="w" onclick="k('HOME')">Home</button></div>
<div><button onclick="k('UP')">&#9650;</button></div>
<div><button onclick="k('LEFT')">&#9664;</button><button onclick="k('OK')" style="background:#4da3ff">OK</button><button onclick="k('RIGHT')">&#9654;</button></div>
<div><button onclick="k('DOWN')">&#9660;</button></div>
<div><button class="w" onclick="k('MENU')">Menu</button></div>
<div><button class="w" onclick="vol('down')">Vol -</button><button class="w" onclick="vol('mute')">Mute</button><button class="w" onclick="vol('up')">Vol +</button></div>
</div>
<div id="apps" style="display:none"></div>
</div>
<script>
var T=localStorage.getItem('tvtoken')||'';
function q(u,cb){fetch(u).then(function(r){if(r.status==401){localStorage.removeItem('tvtoken');T='';show();}return r.json()}).then(function(j){if(cb)cb(j)}).catch(function(){msg('Connection error')})}
function msg(s){document.getElementById('msg').textContent=s}
function show(){document.getElementById('pair').style.display=T?'none':'block';document.getElementById('main').style.display=T?'block':'none'}
function pairNow(){var p=document.getElementById('pin').value;fetch('/api/pair?pin='+encodeURIComponent(p)).then(function(r){return r.json()}).then(function(j){if(j.ok){T=j.token;localStorage.setItem('tvtoken',T);show()}else{alert(j.err=='locked'?'Too many attempts, wait 1 min':'Wrong PIN')}})}
function k(x){if(navigator.vibrate)navigator.vibrate(15);q('/api/key?k='+x+'&t='+T)}
function vol(d){q('/api/vol?d='+d+'&t='+T)}
function tab(i){document.getElementById('rem').style.display=i?'none':'block';document.getElementById('apps').style.display=i?'block':'none';if(i)loadApps()}
function loadApps(){q('/api/apps?t='+T,function(a){var h='';for(var i=0;i<a.length;i++){h+='<button data-p="'+a[i].p+'">'+a[i].n.replace(/</g,'')+'</button>'}var d=document.getElementById('apps');d.innerHTML=h;var b=d.getElementsByTagName('button');for(var j=0;j<b.length;j++){b[j].onclick=function(){q('/api/launch?p='+encodeURIComponent(this.getAttribute('data-p'))+'&t='+T)}}})}
show();
</script></body></html>"""
}
