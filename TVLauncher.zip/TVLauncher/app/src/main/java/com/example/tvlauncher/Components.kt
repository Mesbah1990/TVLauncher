package com.example.tvlauncher

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import kotlinx.coroutines.delay
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin

val Gold: Color get() = Look.accent
val Glass = Color(0xB3101A3C)
val Line = Color(0x33FFFFFF)

private class PressState { var down = false; var long = false }

/**
 * D-pad friendly card: scales up + accent border (+ glow) when focused.
 * Long-press on OK/Enter (or the Menu key, or touch long-press) calls [onLongClick].
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    background: Brush = SolidColor(Glass),
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    highlight: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val active = focused || highlight
    val scale by animateFloatAsState(if (active) 1.05f else 1f, label = "scale")
    val st = remember { PressState() }
    val m = if (focusRequester != null) modifier.focusRequester(focusRequester) else modifier
    Box(
        modifier = m
            .zIndex(if (active) 1f else 0f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .then(
                if (focused && Look.glow) Modifier.shadow(18.dp, shape, ambientColor = Gold, spotColor = Gold)
                else Modifier
            )
            .clip(shape)
            .background(background)
            .border(if (active) 3.dp else 1.dp, if (active) Gold else Line, shape)
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { e ->
                val k = e.key
                if (k == Key.Menu) {
                    if (e.type == KeyEventType.KeyDown && onLongClick != null) { onLongClick(); true } else onLongClick != null
                } else if (k == Key.DirectionCenter || k == Key.Enter || k == Key.NumPadEnter) {
                    when (e.type) {
                        KeyEventType.KeyDown -> {
                            if (!st.down) { st.down = true; st.long = false }
                            else if (!st.long && onLongClick != null && e.nativeKeyEvent.repeatCount >= 1) {
                                st.long = true
                                onLongClick()
                            }
                            true
                        }
                        KeyEventType.KeyUp -> {
                            if (st.down && !st.long) onClick()
                            st.down = false; st.long = false
                            true
                        }
                        else -> false
                    }
                } else false
            }
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null,
                onClick = onClick, onLongClick = onLongClick,
            ),
        content = content,
    )
}

/** Soft diagonal light band that passes over a card every few seconds (cinematic shine). */
@Composable
fun Sweep() {
    if (!Look.sweep) return
    val tr = rememberInfiniteTransition(label = "sweep")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "p")
    Box(
        Modifier.fillMaxSize().drawWithContent {
            drawContent()
            if (p < 0.35f) {
                val f = p / 0.35f
                val w = size.width
                val x = -w * 0.4f + f * w * 1.8f
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color(0x30FFFFFF), Color.Transparent),
                        start = Offset(x, 0f), end = Offset(x + w * 0.35f, size.height * 0.5f),
                    )
                )
            }
        }
    )
}

@Composable
fun TvDialog(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.55f)
                .widthIn(max = 560.dp)
                .heightIn(max = 440.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xF2101830))
                .border(1.dp, Line, RoundedCornerShape(20.dp))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(title, color = Gold, fontSize = 22.sp)
            content()
        }
    }
}

@Composable
fun DialogButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    selected: Boolean = false,
) {
    FocusCard(
        onClick, modifier.fillMaxWidth(), RoundedCornerShape(12.dp),
        SolidColor(if (selected) Color(0x663D7BFF) else Color(0x33FFFFFF)), focusRequester,
    ) {
        Text(
            text, color = Color.White, fontSize = 16.sp,
            modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 14.dp, vertical = 10.dp),
        )
    }
}

/** App icon (square) or banner loaded off the main thread. */
@Composable
fun AppIcon(pkg: String, modifier: Modifier = Modifier, preferBanner: Boolean = false, contentScale: ContentScale = ContentScale.Fit) {
    val ctx = LocalContext.current
    val v by produceState<Visual?>(null, pkg, preferBanner) {
        value = withContext(Dispatchers.IO) { Apps.visual(ctx, pkg, preferBanner) }
    }
    v?.let { Image(it.bitmap, null, modifier, contentScale = contentScale) }
}

@Composable
fun Equalizer(active: Boolean, color: Color = Gold) {
    val tr = rememberInfiniteTransition(label = "eq")
    Row(Modifier.height(18.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        listOf(380, 520, 700).forEach { d ->
            val h by tr.animateFloat(0.3f, 1f, infiniteRepeatable(tween(d, easing = LinearEasing), RepeatMode.Reverse), label = "bar")
            Box(
                Modifier
                    .width(4.dp)
                    .fillMaxHeight(if (active) h else 0.4f)
                    .background(color, RoundedCornerShape(2.dp))
            )
        }
    }
}


// ───────────────────────── Wallpapers ─────────────────────────

class Preset(val sky: List<Color>, val far: Color, val near: Color, val ground: Color)

val Presets = listOf(
    Preset(listOf(Color(0xFF1B1A55), Color(0xFF6B3F9E), Color(0xFFE8734A), Color(0xFFF7B267)), Color(0xFF3A3470), Color(0xFF14183A), Color(0xFF0A0F2C)),
    Preset(listOf(Color(0xFF020617), Color(0xFF0B1E4A), Color(0xFF1D4ED8)), Color(0xFF16306E), Color(0xFF0A1633), Color(0xFF020617)),
    Preset(listOf(Color(0xFF03150F), Color(0xFF0B5D3B), Color(0xFF34D399)), Color(0xFF0F4D36), Color(0xFF062B1E), Color(0xFF021208)),
    Preset(listOf(Color(0xFF0A0A0A), Color(0xFF3B2A0E), Color(0xFFB8860B)), Color(0xFF2A1F0A), Color(0xFF120D04), Color(0xFF050402)),
    Preset(listOf(Color(0xFF1E0A3C), Color(0xFF4C1D95), Color(0xFFDB2777)), Color(0xFF3B1470), Color(0xFF1A0A3A), Color(0xFF0A0418)),
)

@Composable
fun PresetWallpaper(index: Int, modifier: Modifier = Modifier) {
    val p = Presets[index.coerceIn(0, Presets.lastIndex)]
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(p.sky))
        fun ridge(base: Float, amp: Float, seed: Float, color: Color) {
            val path = Path()
            path.moveTo(0f, h)
            val n = 40
            for (i in 0..n) {
                val x = w * i / n
                val wave = 0.5f + 0.5f * sin(i * 0.9f + seed) * cos(i * 0.37f + seed * 0.5f)
                path.lineTo(x, h * base - amp * h * wave)
            }
            path.lineTo(w, h)
            path.close()
            drawPath(path, color)
        }
        ridge(0.64f, 0.14f, 1f, p.far)
        ridge(0.76f, 0.10f, 4f, p.near)
        drawRect(
            Brush.verticalGradient(listOf(p.ground.copy(alpha = 0f), p.ground), startY = h * 0.72f, endY = h)
        )
    }
}

@Composable
fun Wallpaper(prefs: Prefs) {
    val tr = rememberInfiniteTransition(label = "kb")
    val zoom by tr.animateFloat(1.03f, 1.13f, infiniteRepeatable(tween(34000, easing = LinearEasing), RepeatMode.Reverse), label = "z")
    val pan by tr.animateFloat(-1f, 1f, infiniteRepeatable(tween(48000, easing = LinearEasing), RepeatMode.Reverse), label = "p")

    // Ken Burns: slow cinematic zoom + drift on the picture
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            if (Look.kenBurns) {
                scaleX = zoom; scaleY = zoom
                translationX = pan * size.width * 0.012f
            }
        }
    ) {
        val wp = prefs.wallpaper
        if (wp == "file") {
            val bmp by produceState<ImageBitmap?>(null, prefs.wallpaperVersion) {
                value = withContext(Dispatchers.IO) { Images.load(prefs.wallpaperFile) }
            }
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else PresetWallpaper(0, Modifier.fillMaxSize())
        } else {
            PresetWallpaper(wp.removePrefix("preset:").toIntOrNull() ?: 0, Modifier.fillMaxSize())
        }
    }

    // slight scrim so text stays readable on any picture
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0x66000000), Color(0x14000000), Color(0xA0000000)))
        )
    )

    if (Look.vignette) {
        Box(
            Modifier.fillMaxSize().drawBehind {
                drawRect(
                    Brush.radialGradient(
                        0f to Color.Transparent, 0.5f to Color.Transparent, 1f to Color(0xC0000000),
                        center = center, radius = size.width * 0.62f,
                    )
                )
            }
        )
    }
    if (Look.grain) FilmGrain()
    if (Look.letterbox) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().weight(0.055f).background(Color.Black))
            Spacer(Modifier.weight(0.89f))
            Box(Modifier.fillMaxWidth().weight(0.055f).background(Color.Black))
        }
    }
}

private fun noiseTile(): ImageBitmap {
    val n = 128
    val px = IntArray(n * n)
    val r = java.util.Random(7)
    for (i in px.indices) {
        val v = r.nextInt(256)
        px[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
    }
    return android.graphics.Bitmap.createBitmap(px, n, n, android.graphics.Bitmap.Config.ARGB_8888).asImageBitmap()
}

@Composable
fun FilmGrain() {
    val tile = remember { noiseTile() }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(110); tick++ } }
    Canvas(Modifier.fillMaxSize()) {
        val brush = ShaderBrush(ImageShader(tile, TileMode.Repeated, TileMode.Repeated))
        translate((tick * 37 % 128).toFloat(), (tick * 91 % 128).toFloat()) {
            drawRect(brush, topLeft = Offset(-128f, -128f), size = Size(size.width + 128f, size.height + 128f), alpha = 0.07f)
        }
    }
}
