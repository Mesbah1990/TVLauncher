package com.example.tvlauncher

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    companion object {
        @Volatile var current: MainActivity? = null
    }

    fun sendKey(code: Int) {
        runOnUiThread {
            val t = SystemClock.uptimeMillis()
            dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
            dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
        }
    }

    override fun onPause() {
        super.onPause()
        if (current === this) current = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp() }
    }

    // زر "الرئيسية" في الريموت أثناء عمل اللانشر → العودة للشاشة الرئيسية
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) Nav.homeTick++
    }

    override fun onResume() {
        super.onResume()
        current = this
        Nav.resumeTick++
    }
}
