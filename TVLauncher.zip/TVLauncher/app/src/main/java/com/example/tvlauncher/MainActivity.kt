package com.example.tvlauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp() }
    }

    // زر "الرئيسية" في الريموت أثناء عمل اللانشر → العودة للشاشة الرئيسية
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) Nav.homeTick++
    }

    override fun onResume() {
        super.onResume()
        Nav.resumeTick++
    }
}
