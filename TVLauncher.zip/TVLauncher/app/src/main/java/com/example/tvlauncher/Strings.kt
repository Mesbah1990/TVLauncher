package com.example.tvlauncher

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf

enum class Lang(val code: String, val label: String, val rtl: Boolean, val api: String) {
    AR("ar", "العربية", true, "ar"),
    FR("fr", "Français", false, "fr"),
    EN("en", "English", false, "eng");

    companion object {
        fun from(code: String?): Lang = entries.firstOrNull { it.code == code } ?: AR
    }
}

val LocalLang = compositionLocalOf { Lang.AR }

@Composable
@ReadOnlyComposable
fun t(key: String): String = Strings.get(LocalLang.current, key)

object Strings {
    fun get(lang: Lang, key: String): String =
        (when (lang) { Lang.AR -> ar; Lang.FR -> fr; Lang.EN -> en })[key] ?: en[key] ?: key

    private val ar = mapOf(
        "home" to "الرئيسية", "apps" to "التطبيقات", "content" to "المحتوى",
        "favorites" to "المفضلة", "history" to "السجل", "settings" to "الإعدادات",
        "search" to "بحث", "search_hint" to "ابحث عن تطبيق…",
        "live" to "بث مباشر", "live_sub" to "قنوات متنوعة",
        "movies" to "أفلام ومسلسلات", "movies_sub" to "مشاهدة ممتعة",
        "choose_prompt" to "اضغط لاختيار تطبيق",
        "quran" to "القرآن الكريم", "listen" to "استمع الآن",
        "weather" to "الطقس", "security" to "الأمان", "add_app" to "إضافة تطبيق",
        "prayer" to "مواقيت الصلاة", "prayer_next" to "الصلاة القادمة",
        "fajr" to "الفجر", "sunrise" to "الشروق", "dhuhr" to "الظهر",
        "asr" to "العصر", "maghrib" to "المغرب", "isha" to "العشاء",
        "protected" to "الجهاز محمي", "check_security" to "تحقق من الأمان",
        "welcome" to "مرحباً بك في اللانشر", "welcome_sub" to "استمتع بتجربة مشاهدة أفضل",
        "language" to "اللغة", "wallpaper" to "الخلفية",
        "choose_image" to "اختيار صورة من الجهاز", "from_url" to "من رابط إنترنت",
        "enter_url" to "أدخل رابط الصورة (https://…)", "apply" to "تطبيق",
        "cancel" to "إلغاء", "reset" to "الافتراضية",
        "live_app" to "تطبيق البث المباشر", "movies_app" to "تطبيق الأفلام والمسلسلات",
        "choose_app" to "اختر تطبيقاً", "change" to "تغيير", "clear" to "إزالة",
        "not_set" to "غير محدد",
        "remove_fav" to "إزالة من المفضلة", "add_fav" to "إضافة إلى المفضلة",
        "open" to "فتح", "city" to "المدينة",
        "humidity" to "الرطوبة", "wind" to "الرياح", "high" to "العظمى", "low" to "الصغرى",
        "loading" to "جاري التحميل…", "error" to "تعذر التحميل", "no_items" to "لا توجد عناصر",
        "wx_clear" to "مشمس", "wx_cloudy" to "غائم جزئياً", "wx_fog" to "ضباب",
        "wx_rain" to "أمطار", "wx_snow" to "ثلوج", "wx_storm" to "عواصف رعدية",
        "surah" to "سورة", "reciters" to "القرّاء", "surahs" to "السور",
        "now_playing" to "يُشغَّل الآن", "nothing_playing" to "اختر سورة للاستماع",
        "playback_error" to "تعذر التشغيل، تحقق من الإنترنت",
        "hint_home" to "لجعله اللانشر الافتراضي: اضغط زر الرئيسية في الريموت ثم اختر هذا اللانشر و«دائماً».",
        "picker_missing" to "لا يوجد مستعرض ملفات على الجهاز، استخدم «من رابط إنترنت»",
        "saved" to "تم تغيير الخلفية", "failed" to "تعذر استخدام الصورة",
        "app_missing" to "التطبيق غير مثبت", "back" to "رجوع", "kmh" to "كم/س",
        "appearance" to "المظهر", "icon_size" to "حجم الأيقونات", "corner_radius" to "استدارة الزوايا",
        "spacing" to "المسافة بين الأيقونات", "safe_margin" to "هامش الشاشة (للحواف المقصوصة)", "accent" to "لون التمييز",
        "effects" to "التأثيرات السينمائية", "ken_burns" to "حركة الخلفية البطيئة (Ken Burns)", "vignette" to "تعتيم الحواف (Vignette)",
        "grain" to "حبيبات الفيلم", "sweep" to "لمعة ضوئية على البطاقات", "glow" to "توهج العنصر المحدد", "letterbox" to "شريطان سينمائيان",
        "show_hero" to "إظهار بانر القرآن", "show_banners" to "إظهار صف البث والأفلام والصلاة",
        "reset_layout" to "إعادة ترتيب الأيقونات الافتراضي", "move" to "تحريك", "hide" to "إخفاء", "uninstall" to "إلغاء التثبيت",
        "app_info" to "معلومات التطبيق", "remove_home" to "إزالة من الرئيسية",
        "move_hint" to "حرّك بالأسهم ◀ ▶ ثم اضغط موافق للإنهاء", "uninstall_fail" to "تعذر إلغاء التثبيت (قد يكون تطبيق نظام)",
        "on" to "مفعّل", "off" to "معطّل", "long_press_hint" to "نصيحة: اضغط مطولاً على أي أيقونة لتحريكها أو إزالتها أو إلغاء تثبيتها.",
    )

    private val fr = mapOf(
        "home" to "Accueil", "apps" to "Applications", "content" to "Contenu",
        "favorites" to "Favoris", "history" to "Historique", "settings" to "Paramètres",
        "search" to "Recherche", "search_hint" to "Rechercher une application…",
        "live" to "TV en direct", "live_sub" to "Chaînes variées",
        "movies" to "Films et séries", "movies_sub" to "Bon visionnage",
        "choose_prompt" to "Appuyez pour choisir une appli",
        "quran" to "Saint Coran", "listen" to "Écouter",
        "weather" to "Météo", "security" to "Sécurité", "add_app" to "Ajouter une appli",
        "prayer" to "Horaires de prière", "prayer_next" to "Prochaine prière",
        "fajr" to "Fajr", "sunrise" to "Lever du soleil", "dhuhr" to "Dhuhr",
        "asr" to "Asr", "maghrib" to "Maghrib", "isha" to "Isha",
        "protected" to "Appareil protégé", "check_security" to "Vérifier la sécurité",
        "welcome" to "Bienvenue sur le lanceur", "welcome_sub" to "Profitez d'une meilleure expérience",
        "language" to "Langue", "wallpaper" to "Fond d'écran",
        "choose_image" to "Choisir une image", "from_url" to "Depuis un lien",
        "enter_url" to "Lien de l'image (https://…)", "apply" to "Appliquer",
        "cancel" to "Annuler", "reset" to "Par défaut",
        "live_app" to "Appli TV en direct", "movies_app" to "Appli films et séries",
        "choose_app" to "Choisir une application", "change" to "Changer", "clear" to "Retirer",
        "not_set" to "Non défini",
        "remove_fav" to "Retirer des favoris", "add_fav" to "Ajouter aux favoris",
        "open" to "Ouvrir", "city" to "Ville",
        "humidity" to "Humidité", "wind" to "Vent", "high" to "Max", "low" to "Min",
        "loading" to "Chargement…", "error" to "Échec du chargement", "no_items" to "Aucun élément",
        "wx_clear" to "Ensoleillé", "wx_cloudy" to "Partiellement nuageux", "wx_fog" to "Brouillard",
        "wx_rain" to "Pluie", "wx_snow" to "Neige", "wx_storm" to "Orages",
        "surah" to "Sourate", "reciters" to "Récitateurs", "surahs" to "Sourates",
        "now_playing" to "En lecture", "nothing_playing" to "Choisissez une sourate",
        "playback_error" to "Lecture impossible, vérifiez Internet",
        "hint_home" to "Pour le définir par défaut : appuyez sur Accueil sur la télécommande, choisissez ce lanceur puis « Toujours ».",
        "picker_missing" to "Aucun explorateur de fichiers, utilisez « Depuis un lien »",
        "saved" to "Fond d'écran modifié", "failed" to "Image inutilisable",
        "app_missing" to "Application non installée", "back" to "Retour", "kmh" to "km/h",
        "appearance" to "Apparence", "icon_size" to "Taille des icônes", "corner_radius" to "Arrondi des coins",
        "spacing" to "Espacement des icônes", "safe_margin" to "Marge d'écran (bords coupés)", "accent" to "Couleur d'accent",
        "effects" to "Effets cinéma", "ken_burns" to "Mouvement lent du fond (Ken Burns)", "vignette" to "Vignettage des bords",
        "grain" to "Grain de film", "sweep" to "Reflet lumineux sur les cartes", "glow" to "Halo de l'élément sélectionné", "letterbox" to "Bandes cinéma",
        "show_hero" to "Afficher la bannière Coran", "show_banners" to "Afficher la rangée TV / films / prière",
        "reset_layout" to "Réinitialiser l'ordre des icônes", "move" to "Déplacer", "hide" to "Masquer", "uninstall" to "Désinstaller",
        "app_info" to "Infos de l'application", "remove_home" to "Retirer de l'accueil",
        "move_hint" to "Déplacez avec ◀ ▶ puis appuyez sur OK pour terminer", "uninstall_fail" to "Désinstallation impossible (appli système ?)",
        "on" to "Activé", "off" to "Désactivé", "long_press_hint" to "Astuce : appui long sur une icône pour la déplacer, la retirer ou la désinstaller.",
    )

    private val en = mapOf(
        "home" to "Home", "apps" to "Apps", "content" to "Content",
        "favorites" to "Favorites", "history" to "History", "settings" to "Settings",
        "search" to "Search", "search_hint" to "Search for an app…",
        "live" to "Live TV", "live_sub" to "Various channels",
        "movies" to "Movies & Series", "movies_sub" to "Enjoy watching",
        "choose_prompt" to "Press to choose an app",
        "quran" to "Holy Quran", "listen" to "Listen now",
        "weather" to "Weather", "security" to "Security", "add_app" to "Add app",
        "prayer" to "Prayer times", "prayer_next" to "Next prayer",
        "fajr" to "Fajr", "sunrise" to "Sunrise", "dhuhr" to "Dhuhr",
        "asr" to "Asr", "maghrib" to "Maghrib", "isha" to "Isha",
        "protected" to "Device protected", "check_security" to "Check security",
        "welcome" to "Welcome to the Launcher", "welcome_sub" to "Enjoy a better viewing experience",
        "language" to "Language", "wallpaper" to "Wallpaper",
        "choose_image" to "Choose an image", "from_url" to "From a web link",
        "enter_url" to "Image URL (https://…)", "apply" to "Apply",
        "cancel" to "Cancel", "reset" to "Default",
        "live_app" to "Live TV app", "movies_app" to "Movies & series app",
        "choose_app" to "Choose an app", "change" to "Change", "clear" to "Remove",
        "not_set" to "Not set",
        "remove_fav" to "Remove from favorites", "add_fav" to "Add to favorites",
        "open" to "Open", "city" to "City",
        "humidity" to "Humidity", "wind" to "Wind", "high" to "High", "low" to "Low",
        "loading" to "Loading…", "error" to "Could not load", "no_items" to "Nothing here",
        "wx_clear" to "Sunny", "wx_cloudy" to "Partly cloudy", "wx_fog" to "Fog",
        "wx_rain" to "Rain", "wx_snow" to "Snow", "wx_storm" to "Thunderstorms",
        "surah" to "Surah", "reciters" to "Reciters", "surahs" to "Surahs",
        "now_playing" to "Now playing", "nothing_playing" to "Pick a surah to listen",
        "playback_error" to "Playback failed, check your internet",
        "hint_home" to "To make it the default: press Home on the remote, pick this launcher and choose \"Always\".",
        "picker_missing" to "No file browser on this device, use \"From a web link\"",
        "saved" to "Wallpaper changed", "failed" to "Could not use that image",
        "app_missing" to "App is not installed", "back" to "Back", "kmh" to "km/h",
        "appearance" to "Appearance", "icon_size" to "Icon size", "corner_radius" to "Corner roundness",
        "spacing" to "Icon spacing", "safe_margin" to "Screen margin (cropped edges)", "accent" to "Accent color",
        "effects" to "Cinematic effects", "ken_burns" to "Slow background motion (Ken Burns)", "vignette" to "Edge vignette",
        "grain" to "Film grain", "sweep" to "Light sweep on cards", "glow" to "Focus glow", "letterbox" to "Cinema bars",
        "show_hero" to "Show Quran banner", "show_banners" to "Show TV / movies / prayer row",
        "reset_layout" to "Reset icon order", "move" to "Move", "hide" to "Hide", "uninstall" to "Uninstall",
        "app_info" to "App info", "remove_home" to "Remove from home",
        "move_hint" to "Move with ◀ ▶ then press OK to finish", "uninstall_fail" to "Could not uninstall (system app?)",
        "on" to "On", "off" to "Off", "long_press_hint" to "Tip: long-press any icon to move, remove or uninstall it.",
    )
}
