package com.example.tvlauncher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

class Reciter(val nameAr: String, val nameLat: String, val server: String, val surahs: List<Int> = Quran.ALL) {
    fun title(l: Lang) = if (l == Lang.AR) nameAr else nameLat
}

object Quran {
    val ALL = (1..114).toList()

    /** Reliable built-in reciters (mp3quran.net servers). The full list is loaded online. */
    val curated = listOf(
        Reciter("مشاري راشد العفاسي", "Mishary Alafasy", "https://server8.mp3quran.net/afs/"),
        Reciter("عبد الباسط عبد الصمد", "Abdul Basit Abdus Samad", "https://server7.mp3quran.net/basit/"),
        Reciter("محمود خليل الحصري", "Mahmoud Khalil Al-Husary", "https://server13.mp3quran.net/husr/"),
        Reciter("ماهر المعيقلي", "Maher Al-Muaiqly", "https://server12.mp3quran.net/maher/"),
        Reciter("عبد الرحمن السديس", "Abdurrahman As-Sudais", "https://server11.mp3quran.net/sds/"),
        Reciter("سعود الشريم", "Saud Ash-Shuraim", "https://server7.mp3quran.net/shur/"),
        Reciter("سعد الغامدي", "Saad Al-Ghamdi", "https://server7.mp3quran.net/s_gmd/"),
        Reciter("أحمد بن علي العجمي", "Ahmed Al-Ajmi", "https://server10.mp3quran.net/ajm/"),
        Reciter("محمد صديق المنشاوي", "Mohamed Siddiq Al-Minshawi", "https://server10.mp3quran.net/minsh/"),
        Reciter("ياسر الدوسري", "Yasser Al-Dosari", "https://server11.mp3quran.net/yasser/"),
    )

    fun url(r: Reciter, surah: Int) =
        r.server.trimEnd('/') + "/" + String.format(Locale.US, "%03d", surah) + ".mp3"

    fun name(n: Int, lang: Lang): String =
        (if (lang == Lang.AR) ar else lat).getOrElse(n - 1) { "$n" }

    private val ar = listOf(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
        "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
        "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
        "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
        "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
        "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
        "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
        "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
        "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
        "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
        "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
        "المسد", "الإخلاص", "الفلق", "الناس",
    )

    private val lat = listOf(
        "Al-Fatiha", "Al-Baqarah", "Al-Imran", "An-Nisa", "Al-Ma'idah", "Al-An'am", "Al-A'raf", "Al-Anfal", "At-Tawbah", "Yunus",
        "Hud", "Yusuf", "Ar-Ra'd", "Ibrahim", "Al-Hijr", "An-Nahl", "Al-Isra", "Al-Kahf", "Maryam", "Ta-Ha",
        "Al-Anbiya", "Al-Hajj", "Al-Mu'minun", "An-Nur", "Al-Furqan", "Ash-Shu'ara", "An-Naml", "Al-Qasas", "Al-Ankabut", "Ar-Rum",
        "Luqman", "As-Sajdah", "Al-Ahzab", "Saba", "Fatir", "Ya-Sin", "As-Saffat", "Sad", "Az-Zumar", "Ghafir",
        "Fussilat", "Ash-Shura", "Az-Zukhruf", "Ad-Dukhan", "Al-Jathiyah", "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf",
        "Adh-Dhariyat", "At-Tur", "An-Najm", "Al-Qamar", "Ar-Rahman", "Al-Waqi'ah", "Al-Hadid", "Al-Mujadila", "Al-Hashr", "Al-Mumtahanah",
        "As-Saff", "Al-Jumu'ah", "Al-Munafiqun", "At-Taghabun", "At-Talaq", "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Ma'arij",
        "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddaththir", "Al-Qiyamah", "Al-Insan", "Al-Mursalat", "An-Naba", "An-Nazi'at", "Abasa",
        "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Inshiqaq", "Al-Buruj", "At-Tariq", "Al-A'la", "Al-Ghashiyah", "Al-Fajr", "Al-Balad",
        "Ash-Shams", "Al-Layl", "Ad-Duha", "Ash-Sharh", "At-Tin", "Al-Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-Adiyat",
        "Al-Qari'ah", "At-Takathur", "Al-Asr", "Al-Humazah", "Al-Fil", "Quraysh", "Al-Ma'un", "Al-Kawthar", "Al-Kafirun", "An-Nasr",
        "Al-Masad", "Al-Ikhlas", "Al-Falaq", "An-Nas",
    )
}

/** One ExoPlayer for the whole app; state is Compose-observable. */
class QuranPlayer(private val app: App) {
    val exo: ExoPlayer = ExoPlayer.Builder(app)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_SPEECH)
                .build(), true
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_NETWORK)
        .build()

    var reciter by mutableStateOf(app.prefs.loadReciter())
        private set
    var surah by mutableIntStateOf(app.prefs.qSurah)
        private set
    var playing by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var error by mutableStateOf(false)
        private set

    init {
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) next()
            }
            override fun onPlayerError(e: PlaybackException) { error = true; playing = false }
        })
    }

    fun play(r: Reciter = reciter, s: Int = surah) {
        val n = if (s in r.surahs) s else r.surahs.first()
        reciter = r
        surah = n
        error = false
        app.prefs.saveReciter(r, n)
        exo.setMediaItem(MediaItem.fromUri(Quran.url(r, n)))
        exo.prepare()
        exo.play()
    }

    fun toggle() {
        when {
            exo.mediaItemCount == 0 || error -> play()
            exo.isPlaying -> exo.pause()
            else -> exo.play()
        }
    }

    fun next() {
        val l = reciter.surahs
        play(s = l.getOrElse(l.indexOf(surah) + 1) { l.first() })
    }

    fun prev() {
        val l = reciter.surahs
        play(s = l.getOrElse(l.indexOf(surah) - 1) { l.last() })
    }
}
