package com.example.tvlauncher

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

/** Application: holds preferences and the (single) Quran player. */
class App : Application() {
    val prefs by lazy { Prefs(this) }
    val quran by lazy { QuranPlayer(this) }
}

/** Signals from the Activity to Compose. */
object Nav {
    var homeTick by mutableIntStateOf(0)
    var resumeTick by mutableIntStateOf(0)
}

// ───────────────────────── Preferences ─────────────────────────

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    val wallpaperFile = File(ctx.filesDir, "wallpaper.jpg")

    var lang by mutableStateOf(
        Lang.from(sp.getString("lang", null) ?: when (Locale.getDefault().language) {
            "fr" -> "fr"; "en" -> "en"; else -> "ar"
        })
    )
        private set

    /** "preset:N" or "file" */
    var wallpaper by mutableStateOf(sp.getString("wp", "preset:0")!!)
        private set
    var wallpaperVersion by mutableIntStateOf(0)
        private set

    var liveApp by mutableStateOf(sp.getString("live_app", null))
        private set
    var moviesApp by mutableStateOf(sp.getString("movies_app", null))
        private set

    var favorites by mutableStateOf(
        if (sp.contains("fav")) split(sp.getString("fav", "")) else
            listOf("com.google.android.youtube.tv", "com.android.vending")
    )
        private set
    var history by mutableStateOf(split(sp.getString("hist", "")))
        private set

    var cityIndex by mutableIntStateOf(sp.getInt("city", 0))
        private set

    var qSurah = sp.getInt("q_surah", 18)
        private set

    private fun split(s: String?) = (s ?: "").split(",").filter { it.isNotBlank() }

    fun changeLang(l: Lang) { lang = l; sp.edit().putString("lang", l.code).apply() }
    fun changeWallpaper(mode: String) { wallpaper = mode; wallpaperVersion++; sp.edit().putString("wp", mode).apply() }
    fun setLive(pkg: String?) { liveApp = pkg; sp.edit().putString("live_app", pkg).apply() }
    fun setMovies(pkg: String?) { moviesApp = pkg; sp.edit().putString("movies_app", pkg).apply() }
    fun setCity(i: Int) { cityIndex = i; sp.edit().putInt("city", i).apply() }

    fun addFavorite(pkg: String) {
        if (pkg in favorites) return
        favorites = favorites + pkg
        sp.edit().putString("fav", favorites.joinToString(",")).apply()
    }

    fun removeFavorite(pkg: String) {
        favorites = favorites - pkg
        sp.edit().putString("fav", favorites.joinToString(",")).apply()
    }

    fun addHistory(pkg: String) {
        history = (listOf(pkg) + history.filter { it != pkg }).take(30)
        sp.edit().putString("hist", history.joinToString(",")).apply()
    }

    fun saveReciter(r: Reciter, surah: Int) {
        qSurah = surah
        sp.edit().putString("q_server", r.server).putString("q_ar", r.nameAr)
            .putString("q_lat", r.nameLat).putString("q_surahs", r.surahs.joinToString(","))
            .putInt("q_surah", surah).apply()
    }

    fun loadReciter(): Reciter {
        val server = sp.getString("q_server", null) ?: return Quran.curated[0]
        val list = split(sp.getString("q_surahs", "")).mapNotNull { it.toIntOrNull() }.ifEmpty { Quran.ALL }
        return Reciter(sp.getString("q_ar", "")!!, sp.getString("q_lat", "")!!, server, list)
    }
}

// ───────────────────────── Installed apps ─────────────────────────

data class AppInfo(val pkg: String, val label: String)
class Visual(val bitmap: ImageBitmap, val isBanner: Boolean)

object Apps {
    private val cache = ConcurrentHashMap<String, Visual>()

    fun list(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val tv = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        val std = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return (tv + std)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .sortedBy { it.label.lowercase() }
    }

    private fun launchIntent(ctx: Context, pkg: String): Intent? =
        ctx.packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: ctx.packageManager.getLaunchIntentForPackage(pkg)

    fun exists(ctx: Context, pkg: String) = launchIntent(ctx, pkg) != null

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = launchIntent(ctx, pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            (ctx.applicationContext as App).prefs.addHistory(pkg)
            true
        } catch (e: Exception) { false }
    }

    /** Wide banner when the app has one (preferBanner) otherwise square icon. */
    fun visual(ctx: Context, pkg: String, preferBanner: Boolean): Visual? {
        val key = "$pkg/$preferBanner"
        cache[key]?.let { return it }
        val pm = ctx.packageManager
        return try {
            var banner = if (preferBanner) {
                launchIntent(ctx, pkg)?.let { pm.getActivityBanner(it) } ?: pm.getApplicationBanner(pkg)
            } else null
            val v = if (banner != null) Visual(banner.toBitmap(320, 180).asImageBitmap(), true)
            else Visual(pm.getApplicationIcon(pkg).toBitmap(192, 192).asImageBitmap(), false)
            cache[key] = v
            v
        } catch (e: Exception) { null }
    }
}

// ───────────────────────── Cities ─────────────────────────

data class City(val ar: String, val latin: String, val lat: Double, val lon: Double, val method: Int) {
    fun title(l: Lang) = if (l == Lang.AR) ar else latin
}

object Cities {
    // method: Aladhan calculation method (19 = Algeria, 3 = MWL, 5 = Egypt, 4 = Umm Al-Qura ...)
    val all = listOf(
        City("الوادي", "El Oued", 33.3683, 6.8674, 19),
        City("الجزائر العاصمة", "Alger", 36.7538, 3.0588, 19),
        City("وهران", "Oran", 35.6971, -0.6308, 19),
        City("قسنطينة", "Constantine", 36.365, 6.6147, 19),
        City("عنابة", "Annaba", 36.9, 7.7667, 19),
        City("باتنة", "Batna", 35.5559, 6.1741, 19),
        City("سطيف", "Sétif", 36.19, 5.41, 19),
        City("بجاية", "Béjaïa", 36.7509, 5.0567, 19),
        City("تلمسان", "Tlemcen", 34.8828, -1.3167, 19),
        City("بسكرة", "Biskra", 34.85, 5.7333, 19),
        City("ورقلة", "Ouargla", 31.9539, 5.325, 19),
        City("غرداية", "Ghardaïa", 32.49, 3.67, 19),
        City("تمنراست", "Tamanrasset", 22.785, 5.5228, 19),
        City("تقرت", "Touggourt", 33.1, 6.0667, 19),
        City("خنشلة", "Khenchela", 35.43, 7.14, 19),
        City("تبسة", "Tébessa", 35.4, 8.12, 19),
        City("سكيكدة", "Skikda", 36.8761, 6.9067, 19),
        City("جيجل", "Jijel", 36.82, 5.77, 19),
        City("الأغواط", "Laghouat", 33.8, 2.865, 19),
        City("تونس", "Tunis", 36.8065, 10.1815, 18),
        City("الرباط", "Rabat", 34.0209, -6.8416, 21),
        City("الدار البيضاء", "Casablanca", 33.5731, -7.5898, 21),
        City("طرابلس", "Tripoli", 32.8872, 13.1913, 3),
        City("القاهرة", "Le Caire", 30.0444, 31.2357, 5),
        City("مكة المكرمة", "La Mecque", 21.4225, 39.8262, 4),
        City("المدينة المنورة", "Médine", 24.4709, 39.6122, 4),
        City("الرياض", "Riyad", 24.7136, 46.6753, 4),
        City("دبي", "Dubaï", 25.2048, 55.2708, 16),
        City("إسطنبول", "Istanbul", 41.0082, 28.9784, 13),
        City("باريس", "Paris", 48.8566, 2.3522, 12),
        City("مرسيليا", "Marseille", 43.2965, 5.3698, 12),
        City("لندن", "London", 51.5074, -0.1278, 3),
    )
}

// ───────────────────────── Network ─────────────────────────

object Net {
    class Weather(val temp: Int, val code: Int, val humidity: Int, val wind: Int, val hi: Int, val lo: Int)

    class Prayers(val times: List<Pair<String, String>>, val tz: String) {
        /** Next prayer (skips sunrise); wraps to tomorrow's Fajr. */
        fun next(): Pair<String, String>? {
            val cal = Calendar.getInstance(TimeZone.getTimeZone(tz))
            val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val prayers = times.filter { it.first != "Sunrise" }
            return prayers.firstOrNull { minutes(it.second) > now } ?: prayers.firstOrNull()
        }

        private fun minutes(s: String): Int {
            val p = s.split(":")
            return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
        }
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 20_000
            setRequestProperty("User-Agent", "TVLauncher/1.0")
        }

    private fun getBytes(url: String): ByteArray {
        val c = open(url)
        try { return c.inputStream.use { it.readBytes() } } finally { c.disconnect() }
    }

    suspend fun weather(c: City): Weather? = withContext(Dispatchers.IO) {
        runCatching {
            val j = JSONObject(String(getBytes(
                "https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}" +
                    "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                    "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
            )))
            val cur = j.getJSONObject("current")
            val d = j.getJSONObject("daily")
            Weather(
                cur.getDouble("temperature_2m").roundToInt(),
                cur.getInt("weather_code"),
                cur.getInt("relative_humidity_2m"),
                cur.getDouble("wind_speed_10m").roundToInt(),
                d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
            )
        }.getOrNull()
    }

    suspend fun prayers(c: City): Prayers? = withContext(Dispatchers.IO) {
        runCatching {
            val j = JSONObject(String(getBytes(
                "https://api.aladhan.com/v1/timings?latitude=${c.lat}&longitude=${c.lon}&method=${c.method}"
            ))).getJSONObject("data")
            val tm = j.getJSONObject("timings")
            val keys = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
            Prayers(keys.map { it to tm.getString(it).take(5) }, j.getJSONObject("meta").getString("timezone"))
        }.getOrNull()
    }

    private var recitersCache = mapOf<String, List<Reciter>>()

    /** Full reciter list from the mp3quran.net public API (empty on failure). */
    suspend fun reciters(lang: Lang): List<Reciter> {
        recitersCache[lang.code]?.let { return it }
        val list = withContext(Dispatchers.IO) {
            runCatching {
                val arr = JSONObject(String(getBytes("https://mp3quran.net/api/v3/reciters?language=${lang.api}")))
                    .getJSONArray("reciters")
                buildList {
                    for (i in 0 until arr.length()) {
                        val r = arr.getJSONObject(i)
                        val name = r.getString("name")
                        val mo = r.getJSONArray("moshaf")
                        for (k in 0 until mo.length()) {
                            val m = mo.getJSONObject(k)
                            val surahs = m.getString("surah_list").split(",").mapNotNull { it.trim().toIntOrNull() }
                            if (surahs.isEmpty()) continue
                            val label = if (mo.length() > 1) "$name — ${m.optString("name")}" else name
                            add(Reciter(label, label, m.getString("server"), surahs))
                        }
                    }
                }
            }.getOrDefault(emptyList())
        }
        if (list.isNotEmpty()) recitersCache = recitersCache + (lang.code to list)
        return list
    }

    /** Downloads an image, validates it and stores it as the wallpaper. */
    suspend fun saveWallpaperFromUrl(url: String, out: File): Boolean = withContext(Dispatchers.IO) {
        runCatching { Images.saveJpeg(getBytes(url), out) }.getOrDefault(false)
    }
}

// ───────────────────────── Images ─────────────────────────

object Images {
    fun saveJpeg(bytes: ByteArray, out: File): Boolean {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0) return false
        var s = 1
        while (o.outWidth / s > 2560) s *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: return false
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        return true
    }

    fun load(f: File): ImageBitmap? {
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1920) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
    }
}
