package com.example.tvlauncher

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen { Home, Apps, Settings, Quran, TvSettings }

val TAB_IDS = listOf("home", "movies", "series", "sports", "programs", "kids")

sealed interface Dlg {
    data object WeatherInfo : Dlg
    data object PrayerInfo : Dlg
    data object CityPicker : Dlg
    data object UrlInput : Dlg
    data object HadithInfo : Dlg
    data object About : Dlg
    data object DisplayModes : Dlg
    data object AddApp : Dlg
    data class Actions(val pkg: String) : Dlg
    data class TileOptions(val pkg: String) : Dlg
}

@Stable
class UiState(val app: App) {
    var screen by mutableStateOf(Screen.Home)
    var cat by mutableStateOf("home")
    var dialog by mutableStateOf<Dlg?>(null)
    var weather by mutableStateOf<Net.Weather?>(null)
    var prayers by mutableStateOf<Net.Prayers?>(null)
    var apps by mutableStateOf<List<AppInfo>>(emptyList())
    var hadith by mutableIntStateOf(Hadiths.todayIndex())

    /** package of the home tile being moved with the arrow keys (null = not moving). */
    var moving by mutableStateOf<String?>(null)
    private val requesters = HashMap<String, FocusRequester>()
    fun req(id: String) = requesters.getOrPut(id) { FocusRequester() }

    val prefs get() = app.prefs
    val city get() = Cities.all[prefs.cityIndex.coerceIn(0, Cities.all.lastIndex)]

    fun label(pkg: String) = apps.firstOrNull { it.pkg == pkg }?.label

    fun open(ctx: Context, pkg: String) {
        if (!Apps.launch(ctx, pkg))
            Toast.makeText(ctx, Strings.get(prefs.lang, "app_missing"), Toast.LENGTH_SHORT).show()
    }

    fun picked(ctx: Context, pkg: String) {
        prefs.addTo(cat, pkg)
        dialog = null
        Toast.makeText(ctx, Strings.get(prefs.lang, "added"), Toast.LENGTH_SHORT).show()
    }

    /** Arrow keys move the selected tile; OK finishes. Returns true when the key was consumed. */
    fun moveKey(e: KeyEvent, rtl: Boolean): Boolean {
        val id = moving ?: return false
        val k = e.key
        val arrows = k == Key.DirectionLeft || k == Key.DirectionRight || k == Key.DirectionUp || k == Key.DirectionDown
        if (k == Key.DirectionCenter || k == Key.Enter || k == Key.NumPadEnter) {
            if (e.type == KeyEventType.KeyUp) moving = null
            return true
        }
        if (!arrows) return false
        if (e.type == KeyEventType.KeyDown) {
            when (k) {
                Key.DirectionLeft -> prefs.moveIn(cat, id, if (rtl) 1 else -1)
                Key.DirectionRight -> prefs.moveIn(cat, id, if (rtl) -1 else 1)
            }
        }
        return true
    }
}

// ───────────────────────── Root ─────────────────────────

@Composable
fun LauncherApp() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as App
    val prefs = app.prefs
    CompositionLocalProvider(
        LocalLang provides prefs.lang,
        LocalLayoutDirection provides if (prefs.lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Gold)) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                Wallpaper(prefs)
                Root(app)
                // night mode: warm dim overlay (does not block input)
                if (Look.night) Box(Modifier.fillMaxSize().background(Color(0x66281200)))
            }
        }
    }
}

@Composable
fun Root(app: App) {
    val ctx = LocalContext.current
    val ui = remember { UiState(app) }

    LaunchedEffect(Nav.homeTick) { ui.screen = Screen.Home; ui.dialog = null; ui.moving = null }
    LaunchedEffect(Nav.resumeTick) { ui.apps = withContext(Dispatchers.IO) { Apps.list(ctx) } }

    val city = ui.city
    LaunchedEffect(city) {
        ui.weather = null
        ui.prayers = null
        while (true) {
            Net.weather(city)?.let { ui.weather = it }
            Net.prayers(city)?.let { ui.prayers = it }
            delay(30 * 60_000L)
        }
    }

    BackHandler(enabled = ui.dialog == null) {
        when {
            ui.moving != null -> ui.moving = null
            ui.screen != Screen.Home -> ui.screen = Screen.Home
            ui.cat != "home" -> ui.cat = "home"
        }
    }

    // cinematic intro: the launcher fades / settles in
    val intro = remember { Animatable(0f) }
    LaunchedEffect(Unit) { intro.animateTo(1f, tween(900)) }

    Box(
        Modifier.fillMaxSize().graphicsLayer {
            alpha = intro.value
            val sc = 0.97f + 0.03f * intro.value
            scaleX = sc; scaleY = sc
        }
    ) {
        Crossfade(ui.screen, Modifier.fillMaxSize().padding(Look.overscan.dp), animationSpec = tween(300), label = "screen") { sc ->
            when (sc) {
                Screen.Home -> HomeScreen(ui)
                Screen.Apps -> AppsScreen(ui)
                Screen.Settings -> SettingsScreen(ui)
                Screen.Quran -> QuranScreen(ui)
                Screen.TvSettings -> TvSettingsScreen(ui)
            }
        }
    }
    DialogHost(ui)
}

// ───────────────────────── helpers ─────────────────────────

fun weatherInfo(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "wx_clear"
    1, 2, 3 -> "⛅" to "wx_cloudy"
    45, 48 -> "🌫️" to "wx_fog"
    in 51..67, in 80..82 -> "🌧️" to "wx_rain"
    in 71..77, 85, 86 -> "❄️" to "wx_snow"
    in 95..99 -> "⛈️" to "wx_storm"
    else -> "⛅" to "wx_cloudy"
}

fun formatDate(now: Long, lang: Lang): String {
    val loc = when (lang) {
        Lang.AR -> Locale.forLanguageTag("ar-u-nu-latn")
        Lang.FR -> Locale.FRENCH
        Lang.EN -> Locale.ENGLISH
    }
    val s = SimpleDateFormat("EEEE dd MMMM yyyy", loc).format(Date(now))
    return if (lang == Lang.AR) s else s.replaceFirstChar { it.uppercase() }
}

fun openSystem(ctx: Context, action: String) {
    try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}

fun openSecurity(ctx: Context) = openSystem(ctx, Settings.ACTION_SECURITY_SETTINGS)

/** 0 = offline, 1 = Wi-Fi, 2 = Ethernet, 3 = other */
fun netKind(ctx: Context): Int = try {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    when {
        caps == null -> 0
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 2
        else -> 3
    }
} catch (e: Exception) { 0 }

fun onAccent(): Color = if (Look.accent.luminance() > 0.7f) Color.Black else Color.White

@Composable
fun rememberNow(periodMs: Long): State<Long> {
    val now = remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now.value = System.currentTimeMillis(); delay(periodMs) } }
    return now
}

fun Modifier.focusRequesterCompat(r: FocusRequester) = this.then(Modifier.focusRequester(r))

// ───────────────────────── Home ─────────────────────────

@Composable
fun HomeScreen(ui: UiState) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val installed = ui.apps.associateBy { it.pkg }
    val list = ui.prefs.list(ui.cat).filter { installed.containsKey(it) }

    LaunchedEffect(Unit) { delay(400); runCatching { ui.req(list.firstOrNull() ?: "all").requestFocus() } }
    LaunchedEffect(ui.moving) {
        val m = ui.moving
        if (m != null) { delay(150); runCatching { ui.req(m).requestFocus() } }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        TopBar(ui)
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().onPreviewKeyEvent { ui.moveKey(it, rtl) }) {
            val h = maxHeight
            val gap = Look.spacing.dp
            // explicit, scalable sizes: tiles can never overlap each other
            val tileH = (h * 0.24f * Look.iconScale).coerceIn(64.dp, h * 0.36f)
            val stripOn = Look.showPrayer || Look.showQuran || Look.showHadith

            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(gap)) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ClockWeather(ui, maxHeight)
                }
                if (stripOn) InfoStrip(ui, Modifier.fillMaxWidth().height(48.dp))
                LazyRow(
                    Modifier.fillMaxWidth().height(tileH + 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(gap),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                ) {
                    item(key = "all") { AllAppsTile(ui, tileH) }
                    items(list, key = { it }) { pkg -> AppTile(ui, pkg, tileH) }
                    item(key = "add") { AddTile(ui, tileH) }
                }
                CategoryTabs(ui, Modifier.fillMaxWidth().height(52.dp))
            }
        }
    }
}

// ── top bar ──

@Composable
fun TopBar(ui: UiState) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val now by rememberNow(10_000)

    // "secure" only when USB/ADB debugging is off — a real, checkable signal
    val adbOn = remember(Nav.resumeTick, now / 60_000) {
        runCatching { Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 }.getOrDefault(false)
    }
    val net = remember(Nav.resumeTick, now / 10_000) { netKind(ctx) }
    val pill = RoundedCornerShape(50)

    Box(Modifier.fillMaxWidth().height(46.dp)) {
        Row(
            Modifier.align(Alignment.CenterStart).clip(pill).background(Glass).border(1.dp, Line, pill).padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            TopItem({ openSecurity(ctx) }) {
                Icon(if (adbOn) Icons.Filled.Warning else Icons.Filled.VerifiedUser, null,
                    tint = if (adbOn) Color(0xFFFFB020) else Color(0xFF34D399), modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(6.dp))
                Text(t(if (adbOn) "check_security" else "secure"), color = Color.White, fontSize = 14.sp)
            }
            VSep()
            TopItem({ openSystem(ctx, Settings.ACTION_WIFI_SETTINGS) }) {
                Icon(
                    when (net) { 0 -> Icons.Filled.WifiOff; 2 -> Icons.Filled.SettingsEthernet; else -> Icons.Filled.Wifi }, null,
                    tint = if (net == 0) Color(0xFFFFB020) else Color.White, modifier = Modifier.size(22.dp),
                )
            }
            VSep()
            TopItem({ Look.set("night", !Look.night) }) {
                Icon(Icons.Filled.DarkMode, null, tint = if (Look.night) Gold else Color.White, modifier = Modifier.size(22.dp))
            }
        }
        Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TopItem({ ui.dialog = Dlg.CityPicker }) {
                Icon(Icons.Filled.LocationOn, null, tint = Color(0xFF38BDF8), modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(4.dp))
                Text(ui.city.title(lang), color = Color.White, fontSize = 17.sp)
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Text(formatDate(now, lang), color = Color.White, fontSize = 17.sp, maxLines = 1)
        }
        Row(Modifier.align(Alignment.CenterEnd), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TopIcon(Icons.Filled.SettingsApplications) { ui.screen = Screen.TvSettings }
            TopIcon(Icons.Filled.Settings) { ui.screen = Screen.Settings }
        }
    }
}

@Composable
fun VSep() { Box(Modifier.width(1.dp).height(20.dp).background(Line)) }

@Composable
fun TopItem(onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    FocusCard(onClick, Modifier.height(36.dp), RoundedCornerShape(18.dp), SolidColor(Color.Transparent)) {
        Row(Modifier.padding(horizontal = 10.dp).height(36.dp), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

@Composable
fun TopIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusCard(onClick, modifier.size(40.dp), CircleShape, SolidColor(Color.Transparent)) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(26.dp))
    }
}

// ── big clock + weather ──

@Composable
fun ClockWeather(ui: UiState, areaH: Dp) {
    val now by rememberNow(5_000)
    val clockSp = (areaH.value * 0.52f).coerceIn(36f, 100f)
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(
            SimpleDateFormat("HH:mm", Locale.US).format(Date(now)),
            style = TextStyle(
                color = Color.White, fontSize = clockSp.sp, fontWeight = FontWeight.Bold,
                shadow = Shadow(Color(0x99000000), Offset(0f, 4f), 18f),
            ),
        )
        if (Look.showWeather) WeatherPill(ui, compact = areaH < 150.dp)
    }
}

@Composable
fun WeatherPill(ui: UiState, compact: Boolean) {
    val w = ui.weather
    val (emoji, key) = weatherInfo(w?.code ?: 1)
    FocusCard({ ui.dialog = Dlg.WeatherInfo }, Modifier, RoundedCornerShape(24.dp), SolidColor(Color(0x66101830))) {
        Column(Modifier.padding(horizontal = 22.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(emoji, fontSize = 26.sp)
                Text(if (w != null) "${w.temp}°C" else "--", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                VSep()
                Text(if (w != null) t(key) else t("loading"), color = Color(0xFFFFE08A), fontSize = 18.sp)
            }
            if (!compact && w != null) {
                Text("${t("high")} ${w.hi}°   ${t("low")} ${w.lo}°", color = Color(0xCCFFFFFF), fontSize = 13.sp)
            }
        }
    }
}

// ── prayer / Quran / hadith strip ──

@Composable
fun InfoStrip(ui: UiState, modifier: Modifier) {
    val q = ui.app.quran
    val lang = LocalLang.current
    val shape = RoundedCornerShape(Look.radius.dp)
    LaunchedEffect(Unit) { while (true) { delay(45_000); ui.hadith++ } }

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(Look.spacing.dp)) {
        if (Look.showPrayer) {
            val next = ui.prayers?.next()
            FocusCard({ ui.dialog = Dlg.PrayerInfo }, Modifier.weight(1f).fillMaxHeight(), shape) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🕌", fontSize = 22.sp)
                    Column {
                        Text(t("prayer_next"), color = Color(0xB3FFFFFF), fontSize = 10.sp, maxLines = 1)
                        Text(if (next != null) "${t(next.first.lowercase())}  ${next.second}" else t("loading"),
                            color = Color.White, fontSize = 14.sp, maxLines = 1)
                    }
                }
            }
        }
        if (Look.showQuran) {
            Row(Modifier.weight(1.4f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FocusCard({ q.toggle() }, Modifier.weight(1f).fillMaxHeight(), shape) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(if (q.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Gold, modifier = Modifier.size(26.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${t("surah")} ${Quran.name(q.surah, lang)}", color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(q.reciter.title(lang), color = Color(0xB3FFFFFF), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Equalizer(q.playing)
                    }
                }
                FocusCard({ ui.screen = Screen.Quran }, Modifier.width(48.dp).fillMaxHeight(), shape) {
                    Icon(Icons.Filled.Headphones, null, tint = Gold, modifier = Modifier.align(Alignment.Center).size(24.dp))
                }
            }
        }
        if (Look.showHadith) {
            FocusCard({ ui.dialog = Dlg.HadithInfo }, Modifier.weight(2.2f).fillMaxHeight(), shape) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📜", fontSize = 20.sp)
                    Crossfade(ui.hadith % Hadiths.all.size, Modifier.weight(1f), animationSpec = tween(600), label = "hadith") { i ->
                        Text(Hadiths.all[i].text(lang), color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

// ── app tiles ──

@Composable
fun AppTile(ui: UiState, pkg: String, h: Dp) {
    val ctx = LocalContext.current
    val moving = ui.moving == pkg
    FocusCard(
        { ui.open(ctx, pkg) }, Modifier.size(h * 1.2f, h), RoundedCornerShape(Look.radius.dp), SolidColor(Color(0x99101A3C)),
        ui.req(pkg), { ui.dialog = Dlg.TileOptions(pkg) }, moving,
    ) {
        Column(Modifier.align(Alignment.Center).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AppIcon(pkg, Modifier.size(h * 0.5f))
            Text(ui.label(pkg) ?: pkg, color = Color.White, fontSize = (h.value * 0.115f).coerceIn(11f, 18f).sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        }
        if (moving) MoveBadge()
    }
}

@Composable
fun AllAppsTile(ui: UiState, h: Dp) {
    FocusCard({ ui.screen = Screen.Apps }, Modifier.size(h * 1.2f, h), RoundedCornerShape(Look.radius.dp), SolidColor(Color(0x88303A5A)), ui.req("all")) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(Icons.Filled.Apps, null, tint = Color.White, modifier = Modifier.size(h * 0.42f))
            Text(t("all_apps_tile"), color = Color.White, fontSize = (h.value * 0.115f).coerceIn(11f, 18f).sp, maxLines = 1)
        }
    }
}

@Composable
fun AddTile(ui: UiState, h: Dp) {
    FocusCard({ ui.dialog = Dlg.AddApp }, Modifier.size(h * 0.9f, h), RoundedCornerShape(Look.radius.dp), SolidColor(Color(0x55303A5A)), ui.req("add")) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(h * 0.4f))
            Text(t("add_here"), color = Color.White, fontSize = (h.value * 0.115f).coerceIn(11f, 18f).sp, maxLines = 1)
        }
    }
}

@Composable
fun BoxScope.MoveBadge() {
    Text("◀ ▶", color = onAccent(), fontSize = 12.sp,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Gold).padding(horizontal = 8.dp, vertical = 1.dp))
}

// ── category tabs ──

@Composable
fun CategoryTabs(ui: UiState, modifier: Modifier) {
    val icons = listOf(Icons.Filled.Home, Icons.Filled.Movie, Icons.Filled.Tv, Icons.Filled.SportsSoccer, Icons.Filled.Dashboard, Icons.Filled.ChildCare)
    val shape = RoundedCornerShape(50)
    Row(modifier.clip(shape).background(Glass).border(1.dp, Line, shape).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TAB_IDS.forEachIndexed { i, c ->
            val sel = ui.cat == c
            FocusCard(
                { ui.cat = c }, Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(50),
                if (sel) Brush.horizontalGradient(listOf(Look.accent.copy(alpha = 0.7f), Look.accent)) else SolidColor(Color.Transparent),
                ui.req("tab_$c"),
            ) {
                Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(icons[i], null, tint = if (sel) onAccent() else Color.White, modifier = Modifier.size(22.dp))
                    Text(t(if (c == "home") "home" else "cat_$c"), color = if (sel) onAccent() else Color.White, fontSize = 15.sp, maxLines = 1)
                }
            }
        }
    }
}

// ───────────────────────── Dialogs ─────────────────────────

@Composable
fun DialogHost(ui: UiState) {
    when (val d = ui.dialog) {
        null -> {}
        Dlg.WeatherInfo -> WeatherDialog(ui)
        Dlg.PrayerInfo -> PrayerDialog(ui)
        Dlg.CityPicker -> CityDialog(ui)
        Dlg.UrlInput -> UrlDialog(ui)
        Dlg.HadithInfo -> HadithDialog(ui)
        Dlg.About -> AboutDialog(ui)
        Dlg.DisplayModes -> DisplayModesDialog(ui)
        Dlg.AddApp -> PickerDialog(ui)
        is Dlg.Actions -> ActionsDialog(ui, d.pkg)
        is Dlg.TileOptions -> TileOptionsDialog(ui, d.pkg)
    }
}

fun t2(ui: UiState, key: String) = Strings.get(ui.prefs.lang, key)

fun startMove(ctx: Context, ui: UiState, pkg: String) {
    ui.dialog = null
    ui.screen = Screen.Home
    ui.moving = pkg
    Toast.makeText(ctx, t2(ui, "move_hint"), Toast.LENGTH_LONG).show()
}

/** App info + uninstall (shared by the all-apps grid and the home tiles). */
@Composable
fun ColumnScope.AppExtraButtons(ui: UiState, pkg: String) {
    val ctx = LocalContext.current
    DialogButton(t("app_info"), { ui.dialog = null; Apps.info(ctx, pkg) })
    DialogButton(t("uninstall"), {
        ui.dialog = null
        if (!Apps.uninstall(ctx, pkg)) Toast.makeText(ctx, t2(ui, "uninstall_fail"), Toast.LENGTH_SHORT).show()
    })
}

/** Long-press on an app in the all-apps grid: open, put it in tabs, info, uninstall. */
@Composable
fun ActionsDialog(ui: UiState, pkg: String) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(ui.label(pkg) ?: pkg, { ui.dialog = null }, scroll = true) {
        DialogButton(t("open"), { ui.dialog = null; ui.open(ctx, pkg) }, focusRequester = first)
        TAB_IDS.forEach { c ->
            val inTab = pkg in ui.prefs.list(c)
            val name = t(if (c == "home") "home" else "cat_$c")
            DialogButton((if (inTab) "✓  " else "＋  ") + name, {
                if (inTab) ui.prefs.removeFrom(c, pkg) else ui.prefs.addTo(c, pkg)
            }, selected = inTab)
        }
        AppExtraButtons(ui, pkg)
    }
}

/** Long-press on a home tile: move / remove from this tab / info / uninstall. */
@Composable
fun TileOptionsDialog(ui: UiState, pkg: String) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(ui.label(pkg) ?: pkg, { ui.dialog = null }, scroll = true) {
        DialogButton(t("move"), { startMove(ctx, ui, pkg) }, focusRequester = first)
        DialogButton(t(if (ui.cat == "home") "remove_home" else "remove_tab"), { ui.prefs.removeFrom(ui.cat, pkg); ui.dialog = null })
        AppExtraButtons(ui, pkg)
    }
}

@Composable
fun PickerDialog(ui: UiState) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(ui.apps.size) { runCatching { first.requestFocus() } }
    TvDialog(t("choose_app"), { ui.dialog = null }) {
        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ui.apps.size) { i ->
                val a = ui.apps[i]
                FocusCard({ ui.picked(ctx, a.pkg) }, Modifier.fillMaxWidth(), RoundedCornerShape(12.dp),
                    SolidColor(Color(0x33FFFFFF)), if (i == 0) first else null) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppIcon(a.pkg, Modifier.size(36.dp))
                        Text(a.label, color = Color.White, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CityDialog(ui: UiState) {
    val lang = LocalLang.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(t("city"), { ui.dialog = null }) {
        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Cities.all.size) { i ->
                DialogButton(Cities.all[i].title(lang), { ui.prefs.setCity(i); ui.dialog = null },
                    focusRequester = if (i == ui.prefs.cityIndex) first else null, selected = i == ui.prefs.cityIndex)
            }
        }
    }
}

@Composable
fun WeatherDialog(ui: UiState) {
    val w = ui.weather
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog("${t("weather")} — ${ui.city.title(LocalLang.current)}", { ui.dialog = null }) {
        if (w == null) Text(t("loading"), color = Color.White)
        else {
            val (emoji, key) = weatherInfo(w.code)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(emoji, fontSize = 56.sp)
                Column {
                    Text("${w.temp}°C", color = Color.White, fontSize = 40.sp)
                    Text(t(key), color = Color(0xFFFFE08A), fontSize = 16.sp)
                }
            }
            Text("${t("high")}: ${w.hi}°   ${t("low")}: ${w.lo}°", color = Color.White, fontSize = 16.sp)
            Text("${t("humidity")}: ${w.humidity}%", color = Color.White, fontSize = 16.sp)
            Text("${t("wind")}: ${w.wind} ${t("kmh")}", color = Color.White, fontSize = 16.sp)
        }
        DialogButton(t("back"), { ui.dialog = null }, focusRequester = first)
    }
}

@Composable
fun PrayerDialog(ui: UiState) {
    val p = ui.prayers
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog("${t("prayer")} — ${ui.city.title(LocalLang.current)}", { ui.dialog = null }, scroll = true) {
        if (p == null) Text(t("loading"), color = Color.White)
        else {
            val next = p.next()?.first
            p.times.forEach { (k, time) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(if (k == next) Color(0x553D7BFF) else Color(0x22FFFFFF)).padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Text(t(k.lowercase()), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Text(time, color = if (k == next) Gold else Color.White, fontSize = 17.sp)
                }
            }
        }
        DialogButton(t("back"), { ui.dialog = null }, focusRequester = first)
    }
}

@Composable
fun HadithDialog(ui: UiState) {
    val lang = LocalLang.current
    val n = Hadiths.all.size
    val h = Hadiths.all[ui.hadith % n]
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(t("hadith"), { ui.dialog = null }, scroll = true) {
        Text(h.text(lang), color = Color.White, fontSize = 21.sp, lineHeight = 32.sp)
        Text(h.source(lang), color = Gold, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { DialogButton(t("prev"), { ui.hadith = (ui.hadith % n + n - 1) % n }, focusRequester = first) }
            Box(Modifier.weight(1f)) { DialogButton(t("next"), { ui.hadith = (ui.hadith % n + 1) % n }) }
        }
        DialogButton(t("back"), { ui.dialog = null })
    }
}

@Composable
fun AboutDialog(ui: UiState) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(t("about"), { ui.dialog = null }) {
        Text(t("about_text"), color = Color.White, fontSize = 16.sp)
        DialogButton(t("back"), { ui.dialog = null }, focusRequester = first)
    }
}

@Composable
fun UrlDialog(ui: UiState) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf("https://") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(t("from_url"), { ui.dialog = null }) {
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth().focusRequesterCompat(first), singleLine = true, label = { Text(t("enter_url")) })
        DialogButton(if (busy) t("loading") else t("apply"), {
            if (!busy) {
                busy = true
                scope.launch {
                    val ok = Net.saveWallpaperFromUrl(url.trim(), ui.prefs.wallpaperFile)
                    if (ok) ui.prefs.changeWallpaper("file")
                    Toast.makeText(ctx, t2(ui, if (ok) "saved" else "failed"), Toast.LENGTH_SHORT).show()
                    busy = false
                    if (ok) ui.dialog = null
                }
            }
        })
        DialogButton(t("cancel"), { ui.dialog = null })
    }
}
