package com.example.tvlauncher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen { Home, Apps, Content, Favorites, History, Settings, Quran }
enum class Purpose { Live, Movies, Favorite }

sealed interface Dlg {
    data object WeatherInfo : Dlg
    data object PrayerInfo : Dlg
    data object CityPicker : Dlg
    data object UrlInput : Dlg
    data class Pick(val purpose: Purpose, val launch: Boolean) : Dlg
    data class Actions(val pkg: String) : Dlg
    data class TileOptions(val id: String) : Dlg
}

@Stable
class UiState(val app: App) {
    var screen by mutableStateOf(Screen.Home)
    var dialog by mutableStateOf<Dlg?>(null)
    var weather by mutableStateOf<Net.Weather?>(null)
    var prayers by mutableStateOf<Net.Prayers?>(null)
    var apps by mutableStateOf<List<AppInfo>>(emptyList())
    var searchFocus by mutableStateOf(false)

    /** id of the home tile being moved with the arrow keys (null = not moving). */
    var moving by mutableStateOf<String?>(null)
    private val requesters = HashMap<String, FocusRequester>()
    fun req(id: String) = requesters.getOrPut(id) { FocusRequester() }

    /** Arrow keys move the selected tile; OK finishes. Returns true when the key was consumed. */
    fun moveKey(e: KeyEvent, rtl: Boolean): Boolean {
        val id = moving ?: return false
        val k = e.key
        val arrows = k == Key.DirectionLeft || k == Key.DirectionRight || k == Key.DirectionUp || k == Key.DirectionDown
        if (k == Key.DirectionCenter || k == Key.Enter || k == Key.NumPadEnter) {
            if (e.type == KeyEventType.KeyUp) moving = null
            return true
        }
        if (!arrows) return false
        if (e.type == KeyEventType.KeyDown) {
            when (k) {
                Key.DirectionLeft -> prefs.moveTile(id, if (rtl) 1 else -1)
                Key.DirectionRight -> prefs.moveTile(id, if (rtl) -1 else 1)
            }
        }
        return true
    }

    val prefs get() = app.prefs
    val city get() = Cities.all[prefs.cityIndex.coerceIn(0, Cities.all.lastIndex)]

    fun label(pkg: String) = apps.firstOrNull { it.pkg == pkg }?.label

    fun open(ctx: Context, pkg: String) {
        if (!Apps.launch(ctx, pkg))
            Toast.makeText(ctx, Strings.get(prefs.lang, "app_missing"), Toast.LENGTH_SHORT).show()
    }

    /** Live TV / Movies tile: opens the chosen app, or asks which app to use. */
    fun openAssigned(ctx: Context, purpose: Purpose) {
        val pkg = if (purpose == Purpose.Live) prefs.liveApp else prefs.moviesApp
        if (pkg != null && Apps.exists(ctx, pkg)) open(ctx, pkg) else dialog = Dlg.Pick(purpose, true)
    }

    fun picked(ctx: Context, d: Dlg.Pick, pkg: String) {
        when (d.purpose) {
            Purpose.Live -> prefs.setLive(pkg)
            Purpose.Movies -> prefs.setMovies(pkg)
            Purpose.Favorite -> prefs.addFavorite(pkg)
        }
        dialog = null
        if (d.launch) open(ctx, pkg)
    }
}

// ───────────────────────── Root ─────────────────────────

@Composable
fun LauncherApp() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as App
    val prefs = app.prefs
    CompositionLocalProvider(
        LocalLang provides prefs.lang,
        LocalLayoutDirection provides if (prefs.lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Gold)) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                Wallpaper(prefs)
                Root(app)
            }
        }
    }
}

@Composable
fun Root(app: App) {
    val ctx = LocalContext.current
    val ui = remember { UiState(app) }

    LaunchedEffect(Nav.homeTick) { ui.screen = Screen.Home; ui.dialog = null }
    LaunchedEffect(Nav.resumeTick) { ui.apps = withContext(Dispatchers.IO) { Apps.list(ctx) } }

    val city = ui.city
    LaunchedEffect(city) {
        ui.weather = null
        ui.prayers = null
        while (true) {
            Net.weather(city)?.let { ui.weather = it }
            Net.prayers(city)?.let { ui.prayers = it }
            delay(30 * 60_000L)
        }
    }

    BackHandler(enabled = ui.dialog == null) {
        if (ui.moving != null) ui.moving = null else ui.screen = Screen.Home
    }

    // cinematic intro: the launcher fades / settles in
    val intro = remember { Animatable(0f) }
    LaunchedEffect(Unit) { intro.animateTo(1f, tween(900)) }

    Box(
        Modifier.fillMaxSize().graphicsLayer {
            alpha = intro.value
            val sc = 0.97f + 0.03f * intro.value
            scaleX = sc; scaleY = sc
        }
    ) {
        Crossfade(ui.screen, Modifier.fillMaxSize().padding(Look.overscan.dp), animationSpec = tween(300), label = "screen") { sc ->
            when (sc) {
                Screen.Settings -> SettingsScreen(ui)
                Screen.Quran -> QuranScreen(ui)
                else -> Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp)) {
                    TopBar(ui)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (sc) {
                            Screen.Home -> HomeScreen(ui)
                            Screen.Apps -> AppsScreen(ui)
                            Screen.Content -> ContentScreen(ui)
                            Screen.Favorites -> FavoritesScreen(ui)
                            Screen.History -> HistoryScreen(ui)
                            else -> {}
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    BottomBar(ui)
                }
            }
        }
    }
    DialogHost(ui)
}

// ───────────────────────── Top bar ─────────────────────────

fun weatherInfo(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "wx_clear"
    1, 2, 3 -> "⛅" to "wx_cloudy"
    45, 48 -> "🌫️" to "wx_fog"
    in 51..67, in 80..82 -> "🌧️" to "wx_rain"
    in 71..77, 85, 86 -> "❄️" to "wx_snow"
    in 95..99 -> "⛈️" to "wx_storm"
    else -> "⛅" to "wx_cloudy"
}

fun formatDate(now: Long, lang: Lang): String {
    val loc = when (lang) {
        Lang.AR -> Locale.forLanguageTag("ar-u-nu-latn")
        Lang.FR -> Locale.FRENCH
        Lang.EN -> Locale.ENGLISH
    }
    val s = SimpleDateFormat("EEEE dd MMMM yyyy", loc).format(Date(now))
    return if (lang == Lang.AR) s else s.replaceFirstChar { it.uppercase() }
}

@Composable
fun TopBar(ui: UiState) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(10_000) } }

    // "protected" only when USB/ADB debugging is off — a real, checkable signal
    val adbOn = remember(Nav.resumeTick, now / 60_000) {
        runCatching { Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 }.getOrDefault(false)
    }
    val w = ui.weather

    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(SimpleDateFormat("HH:mm", Locale.US).format(Date(now)), color = Color.White, fontSize = 30.sp)
        TopItem({ openSecurity(ctx) }) {
            Icon(if (adbOn) Icons.Filled.Warning else Icons.Filled.VerifiedUser, null,
                tint = if (adbOn) Color(0xFFFFB020) else Color(0xFF34D399), modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(6.dp))
            Text(t(if (adbOn) "check_security" else "protected"), color = Color.White, fontSize = 12.sp)
        }
        TopItem({ ui.dialog = Dlg.WeatherInfo }) {
            val (emoji, key) = weatherInfo(w?.code ?: 0)
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.width(6.dp))
            Column {
                Text(if (w != null) "${w.temp}°C" else "--", color = Color.White, fontSize = 18.sp)
                Text(if (w != null) t(key) else "", color = Color(0xFFFFE08A), fontSize = 11.sp)
            }
        }
        TopItem({ ui.dialog = Dlg.CityPicker }) {
            Icon(Icons.Filled.LocationOn, null, tint = Color(0xFF38BDF8), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(4.dp))
            Text(ui.city.title(lang), color = Color.White, fontSize = 13.sp)
            Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.weight(1f))
        Text(formatDate(now, lang), color = Color.White, fontSize = 14.sp)
        TopIcon(Icons.Filled.Search) { ui.searchFocus = true; ui.screen = Screen.Apps }
        TopIcon(Icons.Filled.Settings) { ui.screen = Screen.Settings }
    }
}

fun openSecurity(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}

@Composable
fun TopItem(onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    FocusCard(onClick, Modifier.fillMaxHeight(), RoundedCornerShape(10.dp), SolidColor(Color.Transparent)) {
        Row(Modifier.padding(horizontal = 8.dp).fillMaxHeight(), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

@Composable
fun TopIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    FocusCard(onClick, Modifier.size(38.dp), CircleShape, SolidColor(Color.Transparent)) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(24.dp))
    }
}

// ───────────────────────── Bottom bar ─────────────────────────

@Composable
fun BottomBar(ui: UiState) {
    val shape = RoundedCornerShape(26.dp)
    Row(Modifier.fillMaxWidth().height(58.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.weight(3.4f).fillMaxHeight().clip(shape).background(Glass).border(1.dp, Color(0x554DA3FF), shape).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NavItem(Screen.Home, Icons.Filled.Home, "home", ui)
            NavItem(Screen.Apps, Icons.Filled.Apps, "apps", ui)
            NavItem(Screen.Content, Icons.Filled.VideoLibrary, "content", ui)
            NavItem(Screen.Favorites, Icons.Filled.Star, "favorites", ui)
            NavItem(Screen.History, Icons.Filled.History, "history", ui)
        }
        Row(
            Modifier.weight(1.3f).fillMaxHeight().clip(shape).background(Glass).border(1.dp, Line, shape).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(t("welcome"), color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t("welcome_sub"), color = Color(0xB3FFFFFF), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Filled.Android, null, tint = Color(0xFF3DDC84), modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
fun RowScope.NavItem(target: Screen, icon: androidx.compose.ui.graphics.vector.ImageVector, key: String, ui: UiState) {
    val selected = ui.screen == target
    FocusCard(
        { ui.screen = target }, Modifier.weight(1f).fillMaxHeight().padding(vertical = 4.dp, horizontal = 2.dp),
        RoundedCornerShape(20.dp), SolidColor(Color.Transparent),
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (selected) Color(0xFF4DA3FF) else Color.White, modifier = Modifier.size(22.dp))
            Text(t(key), color = if (selected) Color(0xFF4DA3FF) else Color.White, fontSize = 12.sp)
        }
        if (selected) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth(0.7f).height(3.dp).background(Color(0xFF4DA3FF)))
    }
}

// ───────────────────────── Home ─────────────────────────

@Composable
fun HomeScreen(ui: UiState) {
    val ctx = LocalContext.current
    val q = ui.app.quran
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl

    val installed = ui.apps.associateBy { it.pkg }
    val tiles = ui.prefs.tiles().filter { !it.startsWith("app:") || installed.containsKey(it.removePrefix("app:")) }

    LaunchedEffect(Unit) { runCatching { ui.req(if ("listen" in tiles) "listen" else tiles.first()).requestFocus() } }
    LaunchedEffect(ui.moving) {
        val m = ui.moving
        if (m != null) { delay(150); runCatching { ui.req(m).requestFocus() } }
    }

    BoxWithConstraints(Modifier.fillMaxSize().onPreviewKeyEvent { ui.moveKey(it, rtl) }) {
        val H = maxHeight
        val gap = Look.spacing.dp
        // explicit, scalable sizes: tiles can never overlap each other
        val tileH = (H * 0.21f * Look.iconScale).coerceIn(64.dp, H * 0.40f)
        val bannerH = (H * 0.19f).coerceIn(56.dp, 110.dp)

        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(gap)) {
            if (Look.showHero) Hero(q, Modifier.fillMaxWidth(0.62f).weight(1f).align(Alignment.CenterHorizontally))
            else Spacer(Modifier.weight(1f))

            LazyRow(
                Modifier.fillMaxWidth().height(tileH + 20.dp),
                horizontalArrangement = Arrangement.spacedBy(gap),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            ) {
                items(tiles, key = { it }) { id -> HomeTile(ui, id, tileH) }
            }

            if (Look.showBanners) {
                Row(Modifier.fillMaxWidth().height(bannerH), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    val bm = Modifier.weight(1f).fillMaxHeight()
                    val next = ui.prayers?.next()
                    WideBanner(
                        t("prayer"),
                        if (next != null) "${t(next.first.lowercase())}  ${next.second}" else t("loading"),
                        "🕌", Brush.horizontalGradient(listOf(Color(0xCC2B2E6B), Color(0xCC4C3B7A))), bm,
                    ) { ui.dialog = Dlg.PrayerInfo }
                    WideBanner(
                        t("live"),
                        ui.prefs.liveApp?.let { ui.label(it) } ?: t("live_sub"),
                        "📡", Brush.horizontalGradient(listOf(Color(0xCC1B2A5E), Color(0xCC27407F))), bm,
                    ) { ui.openAssigned(ctx, Purpose.Live) }
                    WideBanner(
                        t("movies"),
                        ui.prefs.moviesApp?.let { ui.label(it) } ?: t("movies_sub"),
                        "🎬", Brush.horizontalGradient(listOf(Color(0xCC3B1B4F), Color(0xCC1B2A5E))), bm,
                    ) { ui.openAssigned(ctx, Purpose.Movies) }
                }
            }
        }
    }
}

/** One tile of the home row (system tile or a pinned app). Long-press → options. */
@Composable
fun HomeTile(ui: UiState, id: String, h: Dp) {
    val ctx = LocalContext.current
    val q = ui.app.quran
    val req = ui.req(id)
    val onLong = { ui.dialog = Dlg.TileOptions(id) }
    val moving = ui.moving == id
    val w = h * 1.1f
    val ic = h * 0.36f
    val fs = (h.value * 0.125f).coerceIn(11f, 20f)

    when (id) {
        "add" -> SystemTile(t("add_app"), Brush.verticalGradient(listOf(Color(0xFF6B7280), Color(0xFF4B5563))), Modifier.size(w, h),
            { ui.dialog = Dlg.Pick(Purpose.Favorite, false) }, req, onLong, moving, fs) {
            Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(ic))
        }
        "security" -> SystemTile(t("security"), Brush.verticalGradient(listOf(Color(0xFF7C3AED), Color(0xFF4C1D95))), Modifier.size(w, h),
            { openSecurity(ctx) }, req, onLong, moving, fs) {
            Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(ic))
        }
        "weather" -> SystemTile(t("weather"), Brush.verticalGradient(listOf(Color(0xFF38BDF8), Color(0xFF1D4ED8))), Modifier.size(w, h),
            { ui.dialog = Dlg.WeatherInfo }, req, onLong, moving, fs) {
            Text(weatherInfo(ui.weather?.code ?: 1).first, fontSize = (h.value * 0.3f).sp)
        }
        "listen" -> SystemTile(t("listen"), Brush.verticalGradient(listOf(Color(0xFF16245A), Color(0xFF0B1235))), Modifier.size(w, h),
            { q.toggle() }, req, onLong, moving, fs) {
            Icon(Icons.Filled.Headphones, null, tint = Gold, modifier = Modifier.size(ic))
        }
        "quran" -> SystemTile(t("quran"), Brush.verticalGradient(listOf(Color(0xFF22A45D), Color(0xFF0F6B3A))), Modifier.size(w, h),
            { ui.screen = Screen.Quran }, req, onLong, moving, fs) {
            Text("🕌", fontSize = (h.value * 0.3f).sp)
        }
        else -> {
            val pkg = id.removePrefix("app:")
            FavTile(AppInfo(pkg, ui.label(pkg) ?: pkg), Modifier.size(h * 1.6f, h), req, onLong, moving) { ui.open(ctx, pkg) }
        }
    }
}

@Composable
fun Hero(q: QuranPlayer, modifier: Modifier) {
    val lang = LocalLang.current
    val shape = RoundedCornerShape((Look.radius + 6).dp)
    FocusCard(
        { q.toggle() }, modifier, shape,
        Brush.horizontalGradient(listOf(Color(0xE63B2A0E), Color(0xE614110C), Color(0xE60B0B10))),
    ) {
        Box(Modifier.fillMaxSize().border(1.5.dp, Color(0x99C9A227), shape))
        Row(Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(t("quran"), color = Gold, fontSize = 34.sp, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(46.dp).clip(CircleShape).border(2.dp, Gold, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(if (q.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Text(t("listen"), color = Color.White, fontSize = 22.sp)
                }
                val pill = RoundedCornerShape(50)
                Row(
                    Modifier.clip(pill).background(Color(0x66000000)).border(1.dp, Line, pill).padding(horizontal = 16.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Column {
                        Text("${t("surah")} ${Quran.name(q.surah, lang)}", color = Color.White, fontSize = 15.sp, maxLines = 1)
                        Text(q.reciter.title(lang), color = Color(0xB3FFFFFF), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Equalizer(q.playing)
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                Text("📖", fontSize = 84.sp)
            }
        }
        Sweep()
    }
}

@Composable
fun SystemTile(
    label: String, brush: Brush, modifier: Modifier, onClick: () -> Unit,
    focusRequester: FocusRequester?, onLongClick: (() -> Unit)?, moving: Boolean, fontSp: Float,
    icon: @Composable () -> Unit,
) {
    FocusCard(onClick, modifier, RoundedCornerShape(Look.radius.dp), brush, focusRequester, onLongClick, moving) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            icon()
            Text(label, color = Color.White, fontSize = fontSp.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp))
        }
        if (moving) MoveBadge()
    }
}

@Composable
fun BoxScope.MoveBadge() {
    Text("◀ ▶", color = Color.Black, fontSize = 12.sp,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Gold).padding(horizontal = 8.dp, vertical = 1.dp))
}

@Composable
fun FavTile(a: AppInfo, modifier: Modifier, focusRequester: FocusRequester?, onLongClick: (() -> Unit)?, moving: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val v by produceState<Visual?>(null, a.pkg) { value = withContext(Dispatchers.IO) { Apps.visual(ctx, a.pkg, true) } }
    FocusCard(onClick, modifier, RoundedCornerShape(Look.radius.dp), SolidColor(Color(0xFFE9EDFA)), focusRequester, onLongClick, moving) {
        val vis = v
        if (vis != null) {
            if (vis.isBanner) {
                Image(vis.bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(vis.bitmap, null, Modifier.fillMaxHeight(0.55f).aspectRatio(1f))
                    Text(a.label, color = Color(0xFF111827), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 6.dp))
                }
            }
        }
        if (moving) MoveBadge()
    }
}

@Composable
fun WideBanner(title: String, sub: String, emoji: String, brush: Brush, modifier: Modifier, onClick: () -> Unit) {
    FocusCard(onClick, modifier, RoundedCornerShape((Look.radius + 2).dp), brush) {
        Row(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = Color.White, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(sub, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(emoji, fontSize = 36.sp)
        }
        Sweep()
    }
}

// ───────────────────────── Apps / Favorites / History / Content ─────────────────────────

@Composable
fun AppGrid(list: List<AppInfo>, ui: UiState, modifier: Modifier = Modifier, empty: String = t("no_items")) {
    if (list.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(empty, color = Color.White, fontSize = 18.sp) }
        return
    }
    val ctx = LocalContext.current
    val favs = ui.prefs.favorites
    LazyVerticalGrid(GridCells.Adaptive(118.dp), modifier.fillMaxSize(), contentPadding = PaddingValues(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list, key = { it.pkg }) { a ->
            FocusCard({ ui.open(ctx, a.pkg) }, Modifier.aspectRatio(1f), onLongClick = { ui.dialog = Dlg.Actions(a.pkg) }) {
                Column(Modifier.align(Alignment.Center).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AppIcon(a.pkg, Modifier.size(60.dp))
                    Text(a.label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                }
                if (a.pkg in favs) Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(16.dp))
            }
        }
    }
}

@Composable
fun AppsScreen(ui: UiState) {
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(ui.searchFocus) {
        if (ui.searchFocus) { runCatching { focus.requestFocus() }; ui.searchFocus = false }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth(0.5f).focusRequesterCompat(focus),
            singleLine = true, placeholder = { Text(t("search_hint")) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
        )
        val list = if (query.isBlank()) ui.apps else ui.apps.filter { it.label.contains(query, ignoreCase = true) }
        AppGrid(list, ui)
    }
}

private fun Modifier.focusRequesterCompat(r: FocusRequester) = this.then(Modifier.focusRequester(r))

@Composable
fun FavoritesScreen(ui: UiState) {
    val installed = ui.apps.associateBy { it.pkg }
    AppGrid(ui.prefs.favorites.mapNotNull { installed[it] }, ui)
}

@Composable
fun HistoryScreen(ui: UiState) {
    val installed = ui.apps.associateBy { it.pkg }
    AppGrid(ui.prefs.history.mapNotNull { installed[it] }, ui)
}

@Composable
fun ContentScreen(ui: UiState) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxSize().padding(24.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        ContentColumn(ui, Purpose.Live, "📡", t("live"), ui.prefs.liveApp, Modifier.weight(1f)) { ui.openAssigned(ctx, Purpose.Live) }
        ContentColumn(ui, Purpose.Movies, "🎬", t("movies"), ui.prefs.moviesApp, Modifier.weight(1f)) { ui.openAssigned(ctx, Purpose.Movies) }
    }
}

@Composable
fun ContentColumn(ui: UiState, p: Purpose, emoji: String, title: String, pkg: String?, modifier: Modifier, onOpen: () -> Unit) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FocusCard(onOpen, Modifier.fillMaxWidth().weight(1f), RoundedCornerShape(22.dp),
            Brush.horizontalGradient(listOf(Color(0xCC1B2A5E), Color(0xCC3B1B4F)))) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(emoji, fontSize = 64.sp)
                Text(title, color = Color.White, fontSize = 26.sp)
                Text(pkg?.let { ui.label(it) } ?: t("choose_prompt"), color = Color(0xCCFFFFFF), fontSize = 15.sp)
            }
        }
        DialogButton(t("change"), { ui.dialog = Dlg.Pick(p, false) })
        if (pkg != null) DialogButton(t("clear"), { if (p == Purpose.Live) ui.prefs.setLive(null) else ui.prefs.setMovies(null) })
    }
}

// ───────────────────────── Dialogs ─────────────────────────

@Composable
fun DialogHost(ui: UiState) {
    when (val d = ui.dialog) {
        null -> {}
        Dlg.WeatherInfo -> WeatherDialog(ui)
        Dlg.PrayerInfo -> PrayerDialog(ui)
        Dlg.CityPicker -> CityDialog(ui)
        Dlg.UrlInput -> UrlDialog(ui)
        is Dlg.Pick -> PickerDialog(ui, d)
        is Dlg.Actions -> ActionsDialog(ui, d.pkg)
        is Dlg.TileOptions -> TileOptionsDialog(ui, d.id)
    }
}

@Composable
fun ActionsDialog(ui: UiState, pkg: String) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    val isFav = pkg in ui.prefs.favorites
    TvDialog(ui.label(pkg) ?: pkg, { ui.dialog = null }) {
        DialogButton(t("open"), { ui.dialog = null; ui.open(ctx, pkg) }, focusRequester = first)
        DialogButton(t(if (isFav) "remove_fav" else "add_fav"), {
            if (isFav) ui.prefs.removeFavorite(pkg) else ui.prefs.addFavorite(pkg)
            ui.dialog = null
        })
        if (isFav) DialogButton(t("move"), { startMove(ctx, ui, "app:$pkg") })
        AppExtraButtons(ui, pkg)
    }
}

/** App info + uninstall (shared by the apps grid and the home tiles). */
@Composable
fun ColumnScope.AppExtraButtons(ui: UiState, pkg: String) {
    val ctx = LocalContext.current
    DialogButton(t("app_info"), { ui.dialog = null; Apps.info(ctx, pkg) })
    DialogButton(t("uninstall"), {
        ui.dialog = null
        if (!Apps.uninstall(ctx, pkg)) Toast.makeText(ctx, t2(ui, "uninstall_fail"), Toast.LENGTH_SHORT).show()
    })
}

fun startMove(ctx: Context, ui: UiState, id: String) {
    ui.dialog = null
    ui.screen = Screen.Home
    ui.moving = id
    Toast.makeText(ctx, t2(ui, "move_hint"), Toast.LENGTH_LONG).show()
}

@Composable
fun TileOptionsDialog(ui: UiState, id: String) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    val isApp = id.startsWith("app:")
    val pkg = id.removePrefix("app:")
    val title = if (isApp) (ui.label(pkg) ?: pkg) else when (id) {
        "add" -> t("add_app"); "security" -> t("security"); "weather" -> t("weather")
        "listen" -> t("listen"); else -> t("quran")
    }
    TvDialog(title, { ui.dialog = null }) {
        DialogButton(t("move"), { startMove(ctx, ui, id) }, focusRequester = first)
        if (isApp) {
            DialogButton(t("remove_home"), { ui.prefs.removeFavorite(pkg); ui.dialog = null })
            AppExtraButtons(ui, pkg)
        } else if (id != "add") {
            DialogButton(t("hide"), { ui.prefs.hideTile(id); ui.dialog = null })
        }
    }
}

@Composable
fun PickerDialog(ui: UiState, d: Dlg.Pick) {
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    LaunchedEffect(ui.apps.size) { runCatching { first.requestFocus() } }
    TvDialog(t("choose_app"), { ui.dialog = null }) {
        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ui.apps.size) { i ->
                val a = ui.apps[i]
                FocusCard({ ui.picked(ctx, d, a.pkg) }, Modifier.fillMaxWidth().then(Modifier), RoundedCornerShape(12.dp),
                    SolidColor(Color(0x33FFFFFF)), if (i == 0) first else null) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppIcon(a.pkg, Modifier.size(36.dp))
                        Text(a.label, color = Color.White, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CityDialog(ui: UiState) {
    val lang = LocalLang.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(t("city"), { ui.dialog = null }) {
        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Cities.all.size) { i ->
                DialogButton(Cities.all[i].title(lang), { ui.prefs.setCity(i); ui.dialog = null },
                    focusRequester = if (i == ui.prefs.cityIndex) first else null, selected = i == ui.prefs.cityIndex)
            }
        }
    }
}

@Composable
fun WeatherDialog(ui: UiState) {
    val w = ui.weather
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog("${t("weather")} — ${ui.city.title(LocalLang.current)}", { ui.dialog = null }) {
        if (w == null) Text(t("loading"), color = Color.White)
        else {
            val (emoji, key) = weatherInfo(w.code)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(emoji, fontSize = 56.sp)
                Column {
                    Text("${w.temp}°C", color = Color.White, fontSize = 40.sp)
                    Text(t(key), color = Color(0xFFFFE08A), fontSize = 16.sp)
                }
            }
            Text("${t("high")}: ${w.hi}°   ${t("low")}: ${w.lo}°", color = Color.White, fontSize = 16.sp)
            Text("${t("humidity")}: ${w.humidity}%", color = Color.White, fontSize = 16.sp)
            Text("${t("wind")}: ${w.wind} ${t("kmh")}", color = Color.White, fontSize = 16.sp)
        }
        DialogButton(t("back"), { ui.dialog = null }, focusRequester = first)
    }
}

@Composable
fun PrayerDialog(ui: UiState) {
    val p = ui.prayers
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog("${t("prayer")} — ${ui.city.title(LocalLang.current)}", { ui.dialog = null }) {
        if (p == null) Text(t("loading"), color = Color.White)
        else {
            val next = p.next()?.first
            p.times.forEach { (k, time) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(if (k == next) Color(0x553D7BFF) else Color(0x22FFFFFF)).padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Text(t(k.lowercase()), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Text(time, color = if (k == next) Gold else Color.White, fontSize = 17.sp)
                }
            }
        }
        DialogButton(t("back"), { ui.dialog = null }, focusRequester = first)
    }
}

@Composable
fun UrlDialog(ui: UiState) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf("https://") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    TvDialog(t("from_url"), { ui.dialog = null }) {
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth().focusRequesterCompat(first), singleLine = true, label = { Text(t("enter_url")) })
        DialogButton(if (busy) t("loading") else t("apply"), {
            if (!busy) {
                busy = true
                scope.launch {
                    val ok = Net.saveWallpaperFromUrl(url.trim(), ui.prefs.wallpaperFile)
                    if (ok) ui.prefs.changeWallpaper("file")
                    Toast.makeText(ctx, t2(ui, if (ok) "saved" else "failed"), Toast.LENGTH_SHORT).show()
                    busy = false
                    if (ok) ui.dialog = null
                }
            }
        })
        DialogButton(t("cancel"), { ui.dialog = null })
    }
}

fun t2(ui: UiState, key: String) = Strings.get(ui.prefs.lang, key)
