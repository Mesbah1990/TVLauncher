package com.example.tvlauncher

import android.content.ActivityNotFoundException
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ───────────────────────── shared small widgets ─────────────────────────

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        FocusCard(onBack, Modifier.size(42.dp), CircleShape) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
        }
        Text(title, color = Color.White, fontSize = 28.sp)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    FocusCard(onClick, Modifier, RoundedCornerShape(12.dp), SolidColor(if (selected) Look.accent.copy(alpha = 0.55f) else Color(0x33FFFFFF))) {
        Text(text, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x66101830)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, color = Gold, fontSize = 18.sp)
        content()
    }
}

@Composable
fun Stepper(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Chip("−", false, onMinus)
        Text(value, color = Gold, fontSize = 17.sp, modifier = Modifier.widthIn(min = 52.dp), textAlign = TextAlign.Center)
        Chip("+", false, onPlus)
    }
}

@Composable
fun Toggle(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Chip(t(if (on) "on" else "off"), on) { onChange(!on) }
    }
}

// ───────────────────────── All apps ─────────────────────────

@Composable
fun AppGrid(list: List<AppInfo>, ui: UiState, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    if (list.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(t("no_items"), color = Color.White, fontSize = 18.sp) }
        return
    }
    val favs = ui.prefs.favorites
    LazyVerticalGrid(
        GridCells.Adaptive(112.dp), modifier.fillMaxSize(), contentPadding = PaddingValues(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(list, key = { it.pkg }) { a ->
            FocusCard(
                { ui.open(ctx, a.pkg) }, Modifier.aspectRatio(1.05f), RoundedCornerShape(Look.radius.dp),
                SolidColor(Color(0x99101A3C)), onLongClick = { ui.dialog = Dlg.Actions(a.pkg) },
            ) {
                Column(Modifier.align(Alignment.Center).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AppIcon(a.pkg, Modifier.size(58.dp))
                    Text(a.label, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                }
                if (a.pkg in favs) Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(16.dp))
            }
        }
    }
}

@Composable
fun AppsScreen(ui: UiState) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            FocusCard({ ui.screen = Screen.Home }, Modifier.size(42.dp), CircleShape) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            Icon(Icons.Filled.Apps, null, tint = Gold, modifier = Modifier.size(28.dp))
            Text(t("all_apps"), color = Color.White, fontSize = 26.sp, modifier = Modifier.weight(1f))
            OutlinedTextField(
                query, { query = it }, Modifier.width(260.dp), singleLine = true,
                placeholder = { Text(t("search_hint"), fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
            )
        }
        val list = if (query.isBlank()) ui.apps else ui.apps.filter { it.label.contains(query, ignoreCase = true) }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            FocusCard(
                { ui.dialog = Dlg.AddApp }, Modifier.width(110.dp).fillMaxHeight(0.62f).align(Alignment.CenterVertically),
                RoundedCornerShape(Look.radius.dp), SolidColor(Color(0x66101A3C)),
            ) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.Add, null, tint = Look.accent, modifier = Modifier.size(42.dp))
                    Text(t("add_app"), color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }
            AppGrid(list, ui, Modifier.weight(1f))
        }
        val shape = RoundedCornerShape(50)
        Row(
            Modifier.fillMaxWidth().height(44.dp).clip(shape).background(Glass).border(1.dp, Line, shape).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("OK  ${t("ok_open")}", color = Color(0xCCFFFFFF), fontSize = 13.sp)
            Text(t("hold_options"), color = Color(0xCCFFFFFF), fontSize = 13.sp)
            FocusCard({ openSystem(ctx, Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS) }, Modifier.height(34.dp), RoundedCornerShape(50), SolidColor(Color.Transparent)) {
                Row(Modifier.padding(horizontal = 12.dp).height(34.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.Tune, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Text(t("manage_apps"), color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsScreen(ui: UiState) {
    val ctx = LocalContext.current
    val prefs = ui.prefs
    val scope = rememberCoroutineScope()
    var section by remember { mutableIntStateOf(0) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    Images.saveJpeg(bytes, prefs.wallpaperFile)
                }.getOrDefault(false)
            }
            if (ok) prefs.changeWallpaper("file")
            Toast.makeText(ctx, t2(ui, if (ok) "saved" else "failed"), Toast.LENGTH_SHORT).show()
        }
    }
    val pickImage = {
        try { picker.launch("image/*") }
        catch (e: ActivityNotFoundException) { Toast.makeText(ctx, t2(ui, "picker_missing"), Toast.LENGTH_LONG).show() }
    }

    val menu = listOf(
        Icons.Filled.Image to "set_wallpaper", Icons.Filled.HighQuality to "image_res", Icons.Filled.Apps to "arrange",
        Icons.Filled.Tune to "bar_size", Icons.Filled.WbSunny to "weather_loc", Icons.Filled.Tv to "display_opts",
        Icons.Filled.AutoAwesome to "effects",
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FocusCard({ ui.screen = Screen.Home }, Modifier.size(42.dp), CircleShape) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
            }
            Icon(Icons.Filled.Settings, null, tint = Gold, modifier = Modifier.size(28.dp))
            Text(t("launcher_settings"), color = Color.White, fontSize = 26.sp)
        }

        Row(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            // menu (moving focus along it switches the page, like a TV settings screen)
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                menu.forEachIndexed { i, (icon, key) ->
                    FocusCard(
                        { section = i }, Modifier.fillMaxWidth().height(52.dp), RoundedCornerShape(12.dp),
                        SolidColor(if (section == i) Look.accent.copy(alpha = 0.40f) else Glass),
                        if (i == 0) first else null, onFocusChange = { if (it) section = i },
                    ) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(icon, null, tint = if (section == i) Gold else Color.White, modifier = Modifier.size(24.dp))
                            Text(t(key), color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            // page
            Column(Modifier.weight(1.7f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (section) {
                    0 -> WallpaperSection(ui, pickImage)
                    1 -> ResolutionSection(ui)
                    2 -> ArrangeSection(ui)
                    3 -> BarSizeSection()
                    4 -> WeatherLocSection(ui)
                    5 -> DisplaySection(ui)
                    else -> EffectsSection()
                }
            }
        }

        val shape = RoundedCornerShape(50)
        Row(Modifier.fillMaxWidth().height(48.dp).clip(shape).background(Glass).border(1.dp, Line, shape).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            BottomAction(Icons.Filled.CheckCircle, t("save_changes")) {
                Toast.makeText(ctx, t2(ui, "saved_all"), Toast.LENGTH_SHORT).show()
                ui.screen = Screen.Home
            }
            BottomAction(Icons.Filled.Info, t("about")) { ui.dialog = Dlg.About }
            BottomAction(Icons.Filled.Refresh, t("reset_all")) {
                Look.resetAll()
                prefs.resetLayout()
                prefs.changeWallpaper("preset:0")
                Toast.makeText(ctx, t2(ui, "reset_done"), Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@Composable
fun RowScope.BottomAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    FocusCard(onClick, Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(50), SolidColor(Color.Transparent)) {
        Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Text(label, color = Color.White, fontSize = 15.sp, maxLines = 1)
        }
    }
}

@Composable
fun WallpaperSection(ui: UiState, pickImage: () -> Unit) {
    val prefs = ui.prefs
    Section(t("set_wallpaper")) {
        val maxW = 640
        val bmp by produceState<ImageBitmap?>(null, prefs.wallpaperVersion, prefs.wallpaper) {
            value = if (prefs.wallpaper == "file") withContext(Dispatchers.IO) { Images.load(prefs.wallpaperFile, maxW) } else null
        }
        val shape = RoundedCornerShape(14.dp)
        Box(Modifier.fillMaxWidth().height(150.dp).clip(shape).border(1.dp, Line, shape)) {
            val b = bmp
            if (prefs.wallpaper == "file" && b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else PresetWallpaper(prefs.wallpaper.removePrefix("preset:").toIntOrNull() ?: 0, Modifier.fillMaxSize())
            Text("13:20", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
        }
        Text(t("pick_hint"), color = Color(0xCCFFFFFF), fontSize = 14.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(6.dp)) {
            items(Presets.size) { i ->
                FocusCard({ prefs.changeWallpaper("preset:$i") }, Modifier.size(width = 120.dp, height = 68.dp), RoundedCornerShape(10.dp)) {
                    PresetWallpaper(i, Modifier.fillMaxSize())
                    if (prefs.wallpaper == "preset:$i")
                        Box(Modifier.align(Alignment.BottomEnd).padding(4.dp).size(10.dp).background(Gold, CircleShape))
                }
            }
        }
        Chip(t("choose_image"), prefs.wallpaper == "file") { pickImage() }
        Chip(t("from_url"), false) { ui.dialog = Dlg.UrlInput }
        Chip(t("reset"), false) { prefs.changeWallpaper("preset:0") }
    }
}

@Composable
fun ResolutionSection(ui: UiState) {
    val ctx = LocalContext.current
    val prefs = ui.prefs
    Section(t("image_res")) {
        val dm = ctx.resources.displayMetrics
        val size = remember(prefs.wallpaperVersion) { Images.size(prefs.wallpaperFile) }
        Text("${t("screen_res")}:  ${dm.widthPixels} × ${dm.heightPixels}", color = Color.White, fontSize = 16.sp)
        Text("${t("wall_res")}:  ${wallpaperMaxWidth(ctx)} px", color = Color.White, fontSize = 16.sp)
        if (size != null) Text("${t("set_wallpaper")}:  ${size.first} × ${size.second}", color = Color(0xCCFFFFFF), fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip(t("res_auto"), Look.imageRes == 0) { Look.set("res", 0) }
            Chip("720p", Look.imageRes == 1) { Look.set("res", 1) }
            Chip("1080p", Look.imageRes == 2) { Look.set("res", 2) }
            Chip("4K", Look.imageRes == 3) { Look.set("res", 3) }
        }
        Text(t("res_hint"), color = Color(0xCCFFFFFF), fontSize = 13.sp)
    }
}

@Composable
fun ArrangeSection(ui: UiState) {
    Section(t("arrange")) {
        Text(t("arrange_hint"), color = Color.White, fontSize = 15.sp)
        Text(t("long_press_hint"), color = Color(0xCCFFFFFF), fontSize = 13.sp)
        Chip(t("reset_layout"), false) { ui.prefs.resetLayout() }
        Chip(t("home"), false) { ui.screen = Screen.Home }
    }
}

@Composable
fun BarSizeSection() {
    Section(t("bar_size")) {
        Stepper(t("icon_size"), "${(Look.iconScale * 100).toInt()}%",
            { Look.set("scale", (Math.round((Look.iconScale - 0.1f) * 10) / 10f).coerceIn(0.6f, 1.5f)) },
            { Look.set("scale", (Math.round((Look.iconScale + 0.1f) * 10) / 10f).coerceIn(0.6f, 1.5f)) })
        Stepper(t("corner_radius"), "${Look.radius}",
            { Look.set("radius", (Look.radius - 4).coerceIn(0, 36)) }, { Look.set("radius", (Look.radius + 4).coerceIn(0, 36)) })
        Stepper(t("spacing"), "${Look.spacing}",
            { Look.set("spacing", (Look.spacing - 2).coerceIn(4, 28)) }, { Look.set("spacing", (Look.spacing + 2).coerceIn(4, 28)) })
    }
}

@Composable
fun WeatherLocSection(ui: UiState) {
    Section(t("weather_loc")) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(t("city"), color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Chip(ui.city.title(LocalLang.current), false) { ui.dialog = Dlg.CityPicker }
        }
        Toggle(t("show_weather"), Look.showWeather) { Look.set("s_weather", it) }
        Toggle(t("show_prayer"), Look.showPrayer) { Look.set("s_prayer", it) }
    }
}

@Composable
fun DisplaySection(ui: UiState) {
    val prefs = ui.prefs
    Section(t("display_opts")) {
        Text(t("language"), color = Color.White, fontSize = 16.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Lang.entries.forEach { l -> Chip(l.label, l == prefs.lang) { prefs.changeLang(l) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(t("accent"), color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Look.accents.forEach { c ->
                val col = Color(c)
                FocusCard({ Look.set("accent", col.toArgb()) }, Modifier.size(38.dp), CircleShape, SolidColor(col)) {
                    if (Look.accent == col) Icon(Icons.Filled.Check, null, tint = Color.Black, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
        Stepper(t("safe_margin"), "${Look.overscan}",
            { Look.set("overscan", (Look.overscan - 4).coerceIn(0, 60)) }, { Look.set("overscan", (Look.overscan + 4).coerceIn(0, 60)) })
        Toggle(t("show_quran"), Look.showQuran) { Look.set("s_quran", it) }
        Toggle(t("show_hadith"), Look.showHadith) { Look.set("s_hadith", it) }
        Toggle(t("night"), Look.night) { Look.set("night", it) }
    }
}

@Composable
fun EffectsSection() {
    Section(t("effects")) {
        Toggle(t("ken_burns"), Look.kenBurns) { Look.set("kenburns", it) }
        Toggle(t("vignette"), Look.vignette) { Look.set("vignette", it) }
        Toggle(t("sweep"), Look.sweep) { Look.set("sweep", it) }
        Toggle(t("glow"), Look.glow) { Look.set("glow", it) }
        Toggle(t("grain"), Look.grain) { Look.set("grain", it) }
        Toggle(t("letterbox"), Look.letterbox) { Look.set("letterbox", it) }
    }
}

// ───────────────────────── Quran ─────────────────────────

@Composable
fun QuranScreen(ui: UiState) {
    val lang = LocalLang.current
    val q = ui.app.quran
    val remote by produceState(emptyList<Reciter>(), lang) { value = Net.reciters(lang) }
    val all = remember(remote) {
        Quran.curated + remote.filter { r -> Quran.curated.none { it.server == r.server } }
    }
    var browsing by remember { mutableStateOf(q.reciter) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 14.dp)) {
        ScreenHeader(t("quran")) { ui.screen = Screen.Home }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Text("${t("reciters")}  (${all.size})", color = Gold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(4.dp)) {
                    items(all.size) { i ->
                        val r = all[i]
                        ListRow(r.title(lang), r.server == browsing.server, if (i == 0) first else null) { browsing = r }
                    }
                    if (remote.isEmpty()) item { Text(t("loading"), color = Color(0xB3FFFFFF), fontSize = 13.sp) }
                }
            }
            Column(Modifier.weight(1.4f).fillMaxHeight()) {
                Text(t("surahs"), color = Gold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                LazyVerticalGrid(
                    GridCells.Fixed(3), contentPadding = PaddingValues(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(browsing.surahs, key = { it }) { n ->
                        val active = q.reciter.server == browsing.server && q.surah == n
                        ListRow("$n. ${Quran.name(n, lang)}", active, null) { q.play(browsing, n) }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        PlayerBar(q)
    }
}

@Composable
fun ListRow(text: String, selected: Boolean, focusRequester: FocusRequester?, onClick: () -> Unit) {
    FocusCard(onClick, Modifier.fillMaxWidth(), RoundedCornerShape(10.dp),
        SolidColor(if (selected) Color(0x883D7BFF) else Glass), focusRequester) {
        Text(text, color = if (selected) Gold else Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
    }
}

@Composable
fun PlayerBar(q: QuranPlayer) {
    val lang = LocalLang.current
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            pos = q.exo.currentPosition
            dur = q.exo.duration.coerceAtLeast(0L)
            delay(500)
        }
    }
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Glass).border(1.dp, Line, shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // transport buttons keep a fixed left-to-right order in every language
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(Icons.Filled.SkipPrevious, 42.dp) { q.prev() }
                RoundBtn(if (q.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, 54.dp) { q.toggle() }
                RoundBtn(Icons.Filled.SkipNext, 42.dp) { q.next() }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val title = if (q.error) t("playback_error")
            else if (q.playing || q.buffering || pos > 0) "${t("surah")} ${Quran.name(q.surah, lang)}"
            else t("nothing_playing")
            Text(title, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(q.reciter.title(lang), color = Color(0xB3FFFFFF), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            LinearProgressIndicator(
                progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Color(0x33FFFFFF),
            )
        }
        Equalizer(q.playing)
    }
}

@Composable
fun RoundBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, size: Dp, onClick: () -> Unit) {
    FocusCard(onClick, Modifier.size(size), CircleShape, SolidColor(Color(0x33FFFFFF))) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(size * 0.6f))
    }
}
