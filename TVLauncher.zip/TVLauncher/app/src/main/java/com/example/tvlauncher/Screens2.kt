package com.example.tvlauncher

import android.content.ActivityNotFoundException
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        FocusCard(onBack, Modifier.size(42.dp), CircleShape) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
        }
        Text(title, color = Color.White, fontSize = 28.sp)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    FocusCard(onClick, Modifier, RoundedCornerShape(12.dp), SolidColor(if (selected) Color(0x883D7BFF) else Color(0x33FFFFFF))) {
        Text(text, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x66101830)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, color = Gold, fontSize = 18.sp)
        content()
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsScreen(ui: UiState) {
    val ctx = LocalContext.current
    val prefs = ui.prefs
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    Images.saveJpeg(bytes, prefs.wallpaperFile)
                }.getOrDefault(false)
            }
            if (ok) prefs.changeWallpaper("file")
            Toast.makeText(ctx, t2(ui, if (ok) "saved" else "failed"), Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 16.dp)) {
        ScreenHeader(t("settings")) { ui.screen = Screen.Home }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Section(t("language")) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Lang.entries.forEach { l ->
                            Chip(l.label, l == prefs.lang) { prefs.changeLang(l) }
                        }
                    }
                }
            }
            item {
                Section(t("wallpaper")) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(6.dp)) {
                        items(Presets.size) { i ->
                            FocusCard({ prefs.changeWallpaper("preset:$i") }, Modifier.size(width = 128.dp, height = 72.dp),
                                RoundedCornerShape(10.dp), focusRequester = if (i == 0) first else null) {
                                PresetWallpaper(i, Modifier.fillMaxSize())
                                if (prefs.wallpaper == "preset:$i")
                                    Box(Modifier.align(Alignment.BottomEnd).padding(4.dp).size(10.dp).background(Gold, CircleShape))
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Chip(t("choose_image"), prefs.wallpaper == "file") {
                            try { picker.launch("image/*") }
                            catch (e: ActivityNotFoundException) {
                                Toast.makeText(ctx, t2(ui, "picker_missing"), Toast.LENGTH_LONG).show()
                            }
                        }
                        Chip(t("from_url"), false) { ui.dialog = Dlg.UrlInput }
                        Chip(t("reset"), false) { prefs.changeWallpaper("preset:0") }
                    }
                }
            }
            item {
                Section(t("appearance")) {
                    Stepper(t("icon_size"), "${(Look.iconScale * 100).toInt()}%",
                        { Look.set("scale", (Math.round((Look.iconScale - 0.1f) * 10) / 10f).coerceIn(0.6f, 1.5f)) },
                        { Look.set("scale", (Math.round((Look.iconScale + 0.1f) * 10) / 10f).coerceIn(0.6f, 1.5f)) })
                    Stepper(t("corner_radius"), "${Look.radius}",
                        { Look.set("radius", (Look.radius - 4).coerceIn(0, 36)) }, { Look.set("radius", (Look.radius + 4).coerceIn(0, 36)) })
                    Stepper(t("spacing"), "${Look.spacing}",
                        { Look.set("spacing", (Look.spacing - 2).coerceIn(4, 28)) }, { Look.set("spacing", (Look.spacing + 2).coerceIn(4, 28)) })
                    Stepper(t("safe_margin"), "${Look.overscan}",
                        { Look.set("overscan", (Look.overscan - 4).coerceIn(0, 60)) }, { Look.set("overscan", (Look.overscan + 4).coerceIn(0, 60)) })
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(t("accent"), color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Look.accents.forEach { c ->
                            val col = Color(c)
                            FocusCard({ Look.set("accent", col.toArgb()) }, Modifier.size(38.dp), CircleShape, SolidColor(col)) {
                                if (Look.accent == col) Icon(Icons.Filled.Check, null, tint = Color.Black, modifier = Modifier.align(Alignment.Center))
                            }
                        }
                    }
                    Toggle(t("show_hero"), Look.showHero) { Look.set("hero", it) }
                    Toggle(t("show_banners"), Look.showBanners) { Look.set("banners", it) }
                    Chip(t("reset_layout"), false) { prefs.resetLayout() }
                }
            }
            item {
                Section(t("effects")) {
                    Toggle(t("ken_burns"), Look.kenBurns) { Look.set("kenburns", it) }
                    Toggle(t("vignette"), Look.vignette) { Look.set("vignette", it) }
                    Toggle(t("sweep"), Look.sweep) { Look.set("sweep", it) }
                    Toggle(t("glow"), Look.glow) { Look.set("glow", it) }
                    Toggle(t("grain"), Look.grain) { Look.set("grain", it) }
                    Toggle(t("letterbox"), Look.letterbox) { Look.set("letterbox", it) }
                }
            }
            item { AssignSection(ui, Purpose.Live, t("live_app"), prefs.liveApp) }
            item { AssignSection(ui, Purpose.Movies, t("movies_app"), prefs.moviesApp) }
            item {
                Section(t("city")) { Chip(ui.city.title(LocalLang.current), false) { ui.dialog = Dlg.CityPicker } }
            }
            item { Text(t("long_press_hint"), color = Color(0xCCFFFFFF), fontSize = 14.sp) }
            item { Text(t("hint_home"), color = Color(0xCCFFFFFF), fontSize = 14.sp) }
        }
    }
}

@Composable
fun Stepper(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Chip("−", false, onMinus)
        Text(value, color = Gold, fontSize = 17.sp, modifier = Modifier.widthIn(min = 52.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Chip("+", false, onPlus)
    }
}

@Composable
fun Toggle(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Chip(t(if (on) "on" else "off"), on) { onChange(!on) }
    }
}

@Composable
fun AssignSection(ui: UiState, p: Purpose, title: String, pkg: String?) {
    Section(title) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (pkg != null) AppIcon(pkg, Modifier.size(36.dp))
            Text(pkg?.let { ui.label(it) ?: it } ?: t("not_set"), color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Chip(t("change"), false) { ui.dialog = Dlg.Pick(p, false) }
            if (pkg != null) Chip(t("clear"), false) { if (p == Purpose.Live) ui.prefs.setLive(null) else ui.prefs.setMovies(null) }
        }
    }
}

// ───────────────────────── Quran ─────────────────────────

@Composable
fun QuranScreen(ui: UiState) {
    val lang = LocalLang.current
    val q = ui.app.quran
    val remote by produceState(emptyList<Reciter>(), lang) { value = Net.reciters(lang) }
    val all = remember(remote) {
        Quran.curated + remote.filter { r -> Quran.curated.none { it.server == r.server } }
    }
    var browsing by remember { mutableStateOf(q.reciter) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 14.dp)) {
        ScreenHeader(t("quran")) { ui.screen = Screen.Home }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Text("${t("reciters")}  (${all.size})", color = Gold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(4.dp)) {
                    items(all.size) { i ->
                        val r = all[i]
                        ListRow(r.title(lang), r.server == browsing.server, if (i == 0) first else null) { browsing = r }
                    }
                    if (remote.isEmpty()) item { Text(t("loading"), color = Color(0xB3FFFFFF), fontSize = 13.sp) }
                }
            }
            Column(Modifier.weight(1.4f).fillMaxHeight()) {
                Text(t("surahs"), color = Gold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                LazyVerticalGrid(
                    GridCells.Fixed(3), contentPadding = PaddingValues(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(browsing.surahs, key = { it }) { n ->
                        val active = q.reciter.server == browsing.server && q.surah == n
                        ListRow("$n. ${Quran.name(n, lang)}", active, null) { q.play(browsing, n) }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        PlayerBar(q)
    }
}

@Composable
fun ListRow(text: String, selected: Boolean, focusRequester: FocusRequester?, onClick: () -> Unit) {
    FocusCard(onClick, Modifier.fillMaxWidth(), RoundedCornerShape(10.dp),
        SolidColor(if (selected) Color(0x883D7BFF) else Glass), focusRequester) {
        Text(text, color = if (selected) Gold else Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
    }
}

@Composable
fun PlayerBar(q: QuranPlayer) {
    val lang = LocalLang.current
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            pos = q.exo.currentPosition
            dur = q.exo.duration.coerceAtLeast(0L)
            delay(500)
        }
    }
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Glass).border(1.dp, Line, shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // transport buttons keep a fixed left-to-right order in every language
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(Icons.Filled.SkipPrevious, 42.dp) { q.prev() }
                RoundBtn(if (q.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, 54.dp) { q.toggle() }
                RoundBtn(Icons.Filled.SkipNext, 42.dp) { q.next() }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val title = if (q.error) t("playback_error")
            else if (q.playing || q.buffering || pos > 0) "${t("surah")} ${Quran.name(q.surah, lang)}"
            else t("nothing_playing")
            Text(title, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(q.reciter.title(lang), color = Color(0xB3FFFFFF), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            LinearProgressIndicator(
                progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Color(0x33FFFFFF),
            )
        }
        Equalizer(q.playing)
    }
}

@Composable
fun RoundBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    FocusCard(onClick, Modifier.size(size), CircleShape, SolidColor(Color(0x33FFFFFF))) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(size * 0.6f))
    }
}
